#ifndef _MAIN
#define _MAIN

#include "delay.h"
#include "sys.h"
#include "usart.h"	 
#include "string.h"
#include "ov7670.h"
#include "sccb.h"
#include "timer.h"
#include "exit.h"
#include "judge_ball.h"
#include <math.h>
#include "can1.h"

#endif

