#ifndef __CAN1_H_
#define __CAN1_H_
#include "delay.h"

						 							 				    
u8 CAN_Mode_Init(u8 tsjw,u8 tbs2,u8 tbs1,u16 brp,u8 mode);//CAN��ʼ��


void CanReceiveMsgProcess(CanRxMsg *message);

void Set_Color_Current(u8 color);

#endif
