#ifndef __JUDGE
#define __JUDGE

#include "main.h"

enum colour
{
	empty,
	black,
	white,
	pink
};

extern u8 color;
void judge();
#endif