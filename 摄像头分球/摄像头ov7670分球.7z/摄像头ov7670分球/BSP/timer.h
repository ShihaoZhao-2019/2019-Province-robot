#ifndef __TIMER
#define __TIMER
#include "main.h"

extern u8 ov_frame;
void TIM6_Int_Init(u16 arr,u16 psc);





#endif