#include "judge_ball.h"


u8 color;
void judge()
{
	if(average_s+average_h<50)
	{
		color = white;//2
	}else if(average_h <120&&average_h>30)
	{
		color = black;//1
	}else if(average_h>=120||average_h<=20)
	{
		color = pink;
	}else
	{
		color = empty;
	}
	
	
	
	if(color == white){printf("the color is white\r\n");}
	else if(color == black){printf("the color is black\r\n");}
	else if(color == pink){printf("the color is pink\r\n");}
	else {printf("the color is empty\r\n");}

}