#ifndef __EXIT
#define __EXIT

#include "main.h"

extern u8 ov_sta;
void EXTI15_Init(void);	 		


#endif

