#ifndef __OV
#define __OV
#include "main.h"

//ת����ɫ�ռ�
#define minOf3Values( v1, v2, v3 )			( (v1<v2) ? ( (v1<v3) ? (v1) : (v3) ) : ( (v2<v3) ? (v2) : (v3) ) )//ȡrgb�е���Сֵ
#define maxOf3Values( v1, v2, v3 )			( (v1>v2) ? ( (v1>v3) ? (v1) : (v3) ) : ( (v2>v3) ? (v2) : (v3) ) )//ȡrgb�е����ֵ

extern u8 real_h;
extern u8 real_l;
extern u8 real_s;

extern u8 average_h;
extern u8 average_l;
extern u8 average_s;

extern u8 average_r;
extern u8 average_g;
extern u8 average_b;

 
void RGB_TO_HLS(u8 real_r, u8 real_g, u8 real_b);
void camera_refresh(void);


#define LIGHTMODE 1
#define SATURATION 4
#define CONTRAST 0
#define EFFECT 0


#define OV7670_WRST		PAout(0)		//дָ�븴λ
#define OV7670_RCK		PAout(1)		//������ʱ��
#define OV7670_RRST		PAout(4)  		//��ָ�븴λ
#define OV7670_CS		PAout(6)  		//Ƭѡ�ź�(OE)  a6
#define OV7670_WREN		PAout(7)		//д��FIFOʹ��  a7
#define OV7670_VSYNC  	PAin(15)		//ͬ���źż��IO														  					 
#define OV7670_DATA   GPIOB->IDR&0x00FF  					//��������˿�
/////////////////////////////////////////									
	    				 
u8   OV7670_Init(void);		  	   		 
void OV7670_Light_Mode(u8 mode);
void OV7670_Color_Saturation(u8 sat);
void OV7670_Brightness(u8 bright);
void OV7670_Contrast(u8 contrast);
void OV7670_Special_Effects(u8 eft);
void OV7670_Window_Set(u16 sx,u16 sy,u16 width,u16 height);
void OV767_configuration(void);

#endif

