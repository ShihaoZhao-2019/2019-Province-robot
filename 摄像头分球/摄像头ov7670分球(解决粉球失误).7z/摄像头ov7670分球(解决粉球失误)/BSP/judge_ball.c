#include "main.h"


uint8_t color;

void judge()
{
	
  if(average_r>140&&average_g<140)//��ɫ��Rֵ�϶�����140 
	{
		color = (uint8_t)pink;//2
	}else if((average_r + average_g + average_b)<250)
	{
		color = (uint8_t)black;//0
	}else if((average_g<average_r)&&(average_g<average_b))
	{
		color = (uint8_t)white;//1
	}else if((average_r-average_g>100)&&(average_r-average_g)<230)
	{
		color = (uint8_t)pink;//2
	}else
	{
		color = (uint8_t)white;//1
	}
	
	Set_Color_Current(color);

}

