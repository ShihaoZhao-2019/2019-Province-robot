#ifndef __JUDGE
#define __JUDGE

#include "main.h"

enum colour
{
	black,
	white,
	pink
};

extern u8 color;



void judge(void);
#endif

