#include "Ab_fusion.h"
#include "imu.h"
#include "can.h"

#define RAD_45 (double)0.7853982

Enconder enconderA = {0, 0, 0, 0, 0, 0};
Enconder enconderB = {0, 0, 0, 0, 0, 0};
Position POS;

//初始化定位编码器
void posSys_Configure()
{
	GPIO_InitTypeDef gpio;
	
/******************a编码器初始化*******************************/
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

	gpio.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
    gpio.GPIO_Speed = GPIO_Speed_100MHz;
	gpio.GPIO_Mode = GPIO_Mode_AF;
	gpio.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA,&gpio);
	
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource6,GPIO_AF_TIM3);
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource7,GPIO_AF_TIM3);
    TIM_EncoderInterfaceConfig(TIM3, TIM_EncoderMode_TI12, TIM_ICPolarity_Falling, TIM_ICPolarity_Falling);
    TIM_Cmd(TIM3,ENABLE);
	
/******************b编码器初始化*******************************/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	
	gpio.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
    gpio.GPIO_Speed = GPIO_Speed_100MHz;
	gpio.GPIO_Mode = GPIO_Mode_AF;
	gpio.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOB,&gpio);
	
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource6,GPIO_AF_TIM4);
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource7,GPIO_AF_TIM4);
    TIM_EncoderInterfaceConfig(TIM4, TIM_EncoderMode_TI12, TIM_ICPolarity_Falling, TIM_ICPolarity_Falling);
    TIM_Cmd(TIM4,ENABLE);
}
/**
  *****************************************************************************
  *函数名 ： 获取编码器数据
  *函数功能描述 ： 
  *函数参数 ： 
  *函数返回值 ： 
  *作者 ：
  *函数创建日期 ： 
  *函数修改日期 ： 
  *修改人 ：
  *修改原因 ： 
  *版本 ： 
  *历史版本 ： 
  ******************************************************************************
  */
void getEnconderData(int *a, int *b)
{
    enconderA.value = TIM3->CNT;
    if(enconderA.value - enconderA.value_last > 32767)
        enconderA.cnt --;
    else if(enconderA.value - enconderA.value_last < -32767)
        enconderA.cnt ++;
    enconderA.value_last = enconderA.value;
    enconderA.distance = enconderA.cnt * 65535 + enconderA.value;
    enconderA.deff = enconderA.distance - enconderA.distance_last;
    enconderA.distance_last = enconderA.distance;
    
    enconderB.value = TIM4->CNT;
    if(enconderB.value - enconderB.value_last > 32767)
        enconderB.cnt --;
    else if(enconderB.value - enconderB.value_last < -32767)
        enconderB.cnt ++;
    enconderB.value_last = enconderB.value;
    enconderB.distance = enconderB.cnt * 65535 + enconderB.value;
    enconderB.deff = enconderB.distance - enconderB.distance_last;
    enconderB.distance_last = enconderB.distance;
    *a = -enconderA.deff;
    *b = enconderB.deff;
}
/**
  *****************************************************************************
  *函数名 ： 进行位置计算
  *函数功能描述 ： 
  *函数参数 ： 
  *函数返回值 ： 
  *作者 ：
  *函数创建日期 ： 
  *函数修改日期 ： 
  *修改人 ：
  *修改原因 ： 
  *版本 ： 
  *历史版本 ： 
  ******************************************************************************
  */
void doFusion()
{
    float angle_avg = 0;
    double cosB = 0, sinB = 0;
    
    angle_avg = getAngleAVG();
    
    cosB = cos(Angle2Radian(angle_avg) + RAD_45);
    sinB = sin(Angle2Radian(angle_avg) + RAD_45);  
    
    getEnconderData(&POS.ender_A, &POS.ender_B);
    
    POS.pos_X += (float)((POS.ender_A * cosB - POS.ender_B * sinB) * 0.07592f);
    POS.pos_Y += (float)((POS.ender_A * sinB + POS.ender_B * cosB) * 0.07592f);
	Send_POS_Data(POS.pos_X, POS.pos_Y);
	
}
/**
  *****************************************************************************
  *函数名 ：      获取角度均匀值
  *函数功能描述 ：用于微元化计算的微元角度值 
  *函数参数 ： 
  *函数返回值 ： 
  *作者 ：
  *函数创建日期 ： 
  *函数修改日期 ： 
  *修改人 ：
  *修改原因 ： 
  *版本 ： 
  *历史版本 ： 
  ******************************************************************************
  */
float getAngleAVG()
{
    float angleAVG = 0;
    POS.angle_now = yaw_angle - POS.angle_reference;
    angleAVG = (POS.angle_last + POS.angle_now)/2;
    POS.angle_last = POS.angle_now;
    return angleAVG;
}
/**
  *****************************************************************************
  *函数名 ：      获取参考值
  *函数功能描述 ：获取参考值以确定绝对位置
  *函数参数 ： 
  *函数返回值 ： 
  *作者 ：
  *函数创建日期 ： 
  *函数修改日期 ： 
  *修改人 ：
  *修改原因 ： 
  *版本 ： 
  *历史版本 ： 
  ******************************************************************************
  */
float setAngleReference()
{
    POS.angle_reference = angle[0];
}
/**
  *****************************************************************************
  *函数名 ：      获取参考值
  *函数功能描述 ：获取参考值以确定绝对位置
  *函数参数 ： 
  *函数返回值 ： 
  *作者 ：
  *函数创建日期 ： 
  *函数修改日期 ： 
  *修改人 ：
  *修改原因 ： 
  *版本 ： 
  *历史版本 ： 
  ******************************************************************************
  */
double Angle2Radian(float w)
{   
    return (double)((double)w * (double)3.1415926535 / (double)180.0);
}