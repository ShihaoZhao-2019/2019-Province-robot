#ifndef _AB_FUSION_H_
#define _AB_FUSION_H_
#include "sys.h"
#include "math.h"


typedef struct pos__
{
    float angle_now;
    float angle_last;
    float angle_reference;
    float pos_X;
    float pos_Y;
    int ender_A;
    int ender_B;
}Position;
typedef struct encoder__
{
    u16 value;
    u16 value_last;
    int cnt;
    int64_t distance;
    int64_t distance_last;
    int deff;
}Enconder;

extern Position POS;

void posSys_Configure();
void getEnconderData(int *a, int *b);
void doFusion();
float getAngleAVG();
float setAngleReference();
double Angle2Radian(float w);
#endif

