#include "imu.h"
#include "delay.h"
#include "math.h"

#define GYRO_FSR 2 //陀螺仪量程设置0,±250dps;1,±500dps;2,±1000dps;3,±2000dps
#define ACCEL_FSR 0 //加速度计量程设置0,±2g;1,±4g;2,±8g;3,±16g
#define MPU_RATE 1000 //采样频率

MagMaxMinData_t MagMaxMinData;
MagCaliStruct_t MagSavedCaliData = {140,85,-15,1.0,0.85,0.375,0};
GyroCaliStruct_t GyroSavedCaliData;     	    //gyro offset data
AccCaliStruct_t AccSavedCaliData; 
ADJUST adjust;


uint8_t mpu_buf[20]={0};  
volatile MPU6050_RAW_DATA    MPU6050_Raw_Data;    //原始数据
volatile MPU6050_REAL_DATA   MPU6050_Real_Data;
AHRS ahrs;
float Gyro_z_err = 0.0f;

int16_t MPU6050_FIFO[6][11] = {0};//[0]-[9]为最近10次数据 [10]为10次数据的平均值
int16_t HMC5883_FIFO[3][11] = {0};//[0]-[9]为最近10次数据 [10]为10次数据的平均值 注：磁传感器的采样频率慢，所以单独列出

u8  MPU6050_is_DRY = 1;
u8  HMC5883_is_DRY = 1;

volatile float exInt, eyInt, ezInt;  // 误差积分
volatile float q0 = 1.0f;
volatile float q1 = 0.0f;
volatile float q2 = 0.0f;
volatile float q3 = 0.0f;

volatile float mygetqval[9];	//用于存放传感器转换结果的数组
static volatile float gx, gy, gz, ax, ay, az, mx, my, mz;   //作用域仅在此文件中
float HMC5883_lastx,HMC5883_lasty,HMC5883_lastz;
static volatile float q[4]; //　四元数
volatile uint32_t lastUpdate, now; // 采样周期计数 单位 us
volatile float angle[3] = {0};
volatile float yaw_temp,pitch_temp,roll_temp;
volatile float last_yaw_temp,last_pitch_temp,last_roll_temp;
volatile float yaw_angle,pitch_angle,roll_angle; //使用到的角度值

volatile float yaw_angle_sum_gz = 0;
volatile float Yaw_Angle_Offset = 0;

// Fast inverse square-root
/**************************实现函数********************************************
*函数原型:	   float invSqrt(float x)
*功　　能:	   快速计算 1/Sqrt(x) 	
输入参数： 要计算的值
输出参数： 结果
*******************************************************************************/
float invSqrt(float x) {
	float halfx = 0.5f * x;
	float y = x;
	long i = *(long*)&y;
	i = 0x5f3759df - (i>>1);
	y = *(float*)&i;
	y = y * (1.5f - (halfx * y * y));
	return y;
}


u8 IMU_Configure()
{

	u8 res;
	MPU_IIC_Init();//初始化IIC总线
	HMC_IIC_Init();//初始化IIC总线
	
	MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X80);	//复位MPU6050
	delay_ms(100);
	MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X00);	//唤醒MPU6050 
	MPU_Write_Byte(MPU_GYRO_CFG_REG,0x10);//陀螺仪量程设置0,±250dps;1,±500dps;2,±1000dps;3,±2000dps
	MPU_Write_Byte(MPU_ACCEL_CFG_REG,0x00);//加速度计量程设置0,±2g;1,±4g;2,±8g;3,±16g
	MPU_Write_Byte(MPU_SAMPLE_RATE_REG,1000/MPU_RATE-1);					//设置采样率
	MPU_Write_Byte(MPU_INT_EN_REG,0X00);	//关闭所有中断
	MPU_Write_Byte(MPU_USER_CTRL_REG,0X00);	//I2C主模式关闭
	MPU_Write_Byte(MPU_FIFO_EN_REG,0X00);	//关闭FIFO
	MPU_Write_Byte(MPU_INTBP_CFG_REG,0X02);	//INT引脚低电平有效
	MPU_Write_Byte(MPU_INT_EN_REG,0X01);//使能数据就绪中断
//	MPU_Write_Byte(MPU_CFG_REG,0x01);
	HMC_Write_Byte(HMC58X3_CONFA, 0x70);//设置测量速率75Hz
	delay_ms(5);
	HMC_Write_Byte(HMC58X3_CONFB, 0xA0);
	delay_ms(5);
	HMC_Write_Byte(HMC58X3_MODE, 0x00);//设置成连续测量模式
	delay_ms(5);
	HMC_Write_Byte(HMC58X3_CONFA, 6<<2);//设置测量速率75Hz
	delay_ms(5);
	
	
	res=MPU_Read_Byte(MPU_DEVICE_ID_REG);
	if(res==MPU_ADDR)//器件ID正确
	{
		MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X01);	//设置CLKSEL,PLL X轴为参考
		MPU_Write_Byte(MPU_PWR_MGMT2_REG,0X00);	//加速度与陀螺仪都工作
		MPU_Write_Byte(MPU_SAMPLE_RATE_REG,1000/MPU_RATE-1);		//设置采样率
		
		IMU_INT_Configure();
		delay_ms(500);
		MPU6050_Calibration();
		Init_Quaternion();
		
	}else return 1;
	return 0;
}

//中断线配置
u8 IMU_INT_Configure()
{
	GPIO_InitTypeDef   GPIO_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;
	EXTI_InitTypeDef   EXTI_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);//使能GPIOA
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);//使能SYSCFG时钟

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//普通输入模式
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//100M
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉	 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_Init(GPIOB, &GPIO_InitStructure);//初始化GPIOB0 1

	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource0);//PB0 连接到中断线0
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource1);//PB1 连接到中断线1
	/* 配置EXTI_Line3 */
	EXTI_InitStructure.EXTI_Line = EXTI_Line0;//LINE3
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//中断事件
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //下降沿触发 
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;//使能LINE3
	EXTI_Init(&EXTI_InitStructure);//配置
	
	EXTI_InitStructure.EXTI_Line = EXTI_Line1;//LINE3
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//中断事件
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //下降沿触发 
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;//使能LINE3
	EXTI_Init(&EXTI_InitStructure);//配置

	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;//外部中断3
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;//抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;//子优先级2
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//使能外部中断通道
	NVIC_Init(&NVIC_InitStructure);//配置
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;//外部中断3
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;//抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;//子优先级2
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//使能外部中断通道
	NVIC_Init(&NVIC_InitStructure);//配置
}

void MPU6050_Calibration()
{
	int16_t ax,ay,az,gx,gy,gz;
	int16_t gx_sum = 0,gy_sum = 0,gz_sum = 0;
	float gz_sum_f = 0;
	int16_t z_max = 0, z_min = 32767;
	int16_t x_max = 0, x_min = 32767;
	int16_t y_max = 0, y_min = 32767;
	for(int i = 0; i < 20; i++)
	{
		MPU_Read_Len(MPU_ADDR, MPU_ACCEL_XOUTH_REG,14, mpu_buf);
		gx=(((int16_t)mpu_buf[8]) << 8) | mpu_buf[9];
		gy=(((int16_t)mpu_buf[10]) << 8) | mpu_buf[11];
		gz=(((int16_t)mpu_buf[12]) << 8) | mpu_buf[13];
		delay_us(1000);
		if(gz > z_max)
			z_max = gz;
		else if(gz < z_min)
			z_min = gz;
		if(gx > x_max)
			x_max = gx;
		else if(gx < x_min)
			x_min = gx;
		if(gy > y_max)
			y_max = gy;
		else if(gy < y_min)
			y_min = gy;
	}
	GyroSavedCaliData.GyroXOffset = (int16_t)(x_max+x_min)/2;
	GyroSavedCaliData.GyroYOffset = (int16_t)(y_max+y_min)/2;
	GyroSavedCaliData.GyroZOffset = (int16_t)(z_max+z_min)/2;
	for(int i = 0; i < 20; i++)
	{
		for(int j = 0; j < 20; j++)
		{
			MPU_Read_Len(MPU_ADDR, MPU_ACCEL_XOUTH_REG,14, mpu_buf);
			gz=(((int16_t)mpu_buf[12]) << 8) | mpu_buf[13];
			gz_sum = gz_sum + gz - GyroSavedCaliData.GyroZOffset;
			delay_us(500);
		}			
		
		if(gz_sum>0)
			GyroSavedCaliData.GyroZOffset += ((20-i)/2+1);
		else if(gz_sum<0)
			GyroSavedCaliData.GyroZOffset -= ((20-i)/2+1);
		gz_sum = 0;
	}
	for(int i = 0; i < 20; i++)
	{
		for(int j = 0; j < 30; j++)
		{
			MPU_Read_Len(MPU_ADDR, MPU_ACCEL_XOUTH_REG,14, mpu_buf);
			gz=(((int16_t)mpu_buf[12]) << 8) | mpu_buf[13];
			gz_sum_f += ((float)(gz - GyroSavedCaliData.GyroZOffset)/32.8f - Gyro_z_err);	
			delay_us(500);
		}			
		
		if(gz_sum_f>0)
			Gyro_z_err += 0.0011f*((float)(20-i)/2.0f);
		else if(gz_sum_f<0)
			Gyro_z_err -= 0.0012f*((float)(20-i)/2.0f);
		gz_sum_f = 0;
	}
}
/**********************************************************************************/
/*将MPU6050_ax,MPU6050_ay, MPU6050_az,MPU6050_gx, MPU6050_gy, MPU6050_gz处理后存储*/
/**********************************************************************************/
void MPU6050_DataSave(int16_t ax,int16_t ay,int16_t az,int16_t gx,int16_t gy,int16_t gz) //[0]-[9]为最近10次数据 [10]为10次数据的平均值
{
	uint8_t i = 0;
	int32_t sum=0;
	
	for(i=1;i<10;i++)
	{
		MPU6050_FIFO[0][i-1]=MPU6050_FIFO[0][i];
		MPU6050_FIFO[1][i-1]=MPU6050_FIFO[1][i];
		MPU6050_FIFO[2][i-1]=MPU6050_FIFO[2][i];
		MPU6050_FIFO[3][i-1]=MPU6050_FIFO[3][i];
		MPU6050_FIFO[4][i-1]=MPU6050_FIFO[4][i];
		MPU6050_FIFO[5][i-1]=MPU6050_FIFO[5][i];
	}
	
	MPU6050_FIFO[0][9]=ax;//将新的数据放置到 数据的最后面
	MPU6050_FIFO[1][9]=ay;
	MPU6050_FIFO[2][9]=az;
	MPU6050_FIFO[3][9]=gx;
	MPU6050_FIFO[4][9]=gy;
	MPU6050_FIFO[5][9]=gz;
	
	for(i=0;i<10;i++)//求当前数组的合，再取平均值
	{	
		 sum+=MPU6050_FIFO[0][i];
	}
	MPU6050_FIFO[0][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=MPU6050_FIFO[1][i];
	}
	MPU6050_FIFO[1][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=MPU6050_FIFO[2][i];
	}
	MPU6050_FIFO[2][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=MPU6050_FIFO[3][i];
	}
	MPU6050_FIFO[3][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=MPU6050_FIFO[4][i];
	}
	MPU6050_FIFO[4][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=MPU6050_FIFO[5][i];
	}
	MPU6050_FIFO[5][10]=sum/10;
	
}


int16_t MPU6050_Lastax,MPU6050_Lastay,MPU6050_Lastaz
				,MPU6050_Lastgx,MPU6050_Lastgy,MPU6050_Lastgz;
/**************************实现函数********************************************
*函数原型:		void MPU6050_getMotion6(int16_t* ax, int16_t* ay, int16_t* az, int16_t* gx, int16_t* gy, int16_t* gz) {
*功　　能:	    读取 MPU6050的当前测量值
*******************************************************************************/
void MPU6050_getMotion6(int16_t* ax, int16_t* ay, int16_t* az, int16_t* gx, int16_t* gy, int16_t* gz) {
	if(MPU6050_is_DRY)
	{
		MPU6050_is_DRY = 0;
		MPU_Read_Len(MPU_ADDR, MPU_ACCEL_XOUTH_REG,14, mpu_buf);
		HMC58X3_ReadData(&(mpu_buf[14]));  //14-19为陀螺仪数据
		MPU6050_Lastax=(((int16_t)mpu_buf[0]) << 8) | mpu_buf[1];
		MPU6050_Lastay=(((int16_t)mpu_buf[2]) << 8) | mpu_buf[3];
		MPU6050_Lastaz=(((int16_t)mpu_buf[4]) << 8) | mpu_buf[5];
		//跳过温度ADC
		MPU6050_Lastgx=(((int16_t)mpu_buf[8]) << 8) | mpu_buf[9];
		MPU6050_Lastgy=(((int16_t)mpu_buf[10]) << 8) | mpu_buf[11];
		MPU6050_Lastgz=(((int16_t)mpu_buf[12]) << 8) | mpu_buf[13];
			
		MPU6050_DataSave(MPU6050_Lastax,MPU6050_Lastay,MPU6050_Lastaz,MPU6050_Lastgx,MPU6050_Lastgy,MPU6050_Lastgz);  		
		*ax = MPU6050_FIFO[0][10];
		*ay = MPU6050_FIFO[1][10];
		*az = MPU6050_FIFO[2][10];
		*gx = MPU6050_FIFO[3][10] - GyroSavedCaliData.GyroXOffset;
		*gy = MPU6050_FIFO[4][10] - GyroSavedCaliData.GyroYOffset;
		*gz = MPU6050_FIFO[5][10] - GyroSavedCaliData.GyroZOffset;
	} 
	else
	{       //读取上一次的值
		*ax = MPU6050_FIFO[0][10];//=MPU6050_FIFO[0][10];
		*ay = MPU6050_FIFO[1][10];//=MPU6050_FIFO[1][10];
		*az = MPU6050_FIFO[2][10];//=MPU6050_FIFO[2][10];
		*gx = MPU6050_FIFO[3][10] - GyroSavedCaliData.GyroXOffset;//=MPU6050_FIFO[3][10];
		*gy = MPU6050_FIFO[4][10] - GyroSavedCaliData.GyroYOffset;//=MPU6050_FIFO[4][10];
		*gz = MPU6050_FIFO[5][10] - GyroSavedCaliData.GyroZOffset;//=MPU6050_FIFO[5][10];
	}
}

void MPU6050_getlastMotion6(int16_t* ax, int16_t* ay, 
		int16_t* az, int16_t* gx, int16_t* gy, int16_t* gz)
{
	*ax = MPU6050_FIFO[0][10];
	*ay = MPU6050_FIFO[1][10];
	*az = MPU6050_FIFO[2][10];
	*gx = MPU6050_FIFO[3][10]-GyroSavedCaliData.GyroXOffset;
	*gy = MPU6050_FIFO[4][10]-GyroSavedCaliData.GyroYOffset;
	*gz = MPU6050_FIFO[5][10]-GyroSavedCaliData.GyroZOffset;
}

/**************************实现函数********************************************
*函数原型:	   void IMU_getValues(volatile float * values)
*功　　能:	 读取加速度 陀螺仪 磁力计 的当前值  
输入参数： 将结果存放的数组首地址
加速度值：原始数据，-8192-+8192
角速度值：deg/s
磁力计值：原始数据
输出参数：没有
*******************************************************************************/
void IMU_getValues(volatile float * values) {  
		int16_t accgyroval[6];
		int i;
	//读取加速度和陀螺仪的当前ADC
	MPU6050_getMotion6(&accgyroval[0], &accgyroval[1], &accgyroval[2], &accgyroval[3], &accgyroval[4], &accgyroval[5]);
	MPU6050_Raw_Data.Accel_X = accgyroval[0];
	MPU6050_Raw_Data.Accel_Y = accgyroval[1];
	MPU6050_Raw_Data.Accel_Z = accgyroval[2];
	MPU6050_Raw_Data.Gyro_X = accgyroval[3];
	MPU6050_Raw_Data.Gyro_Y = accgyroval[4];
	MPU6050_Raw_Data.Gyro_Z = accgyroval[5];
	
	
    for(i = 0; i<6; i++) {
      if(i < 3) {
        values[i] = (float) accgyroval[i];
      }
      else {
        values[i] = ((float) accgyroval[i]) / 32.8f; //转成度每秒
		//这里已经将量程改成了 1000度每秒  32.8 对应 1度每秒
      }
    }
	values[5] -= Gyro_z_err;
    HMC58X3_mgetValues(&values[6]);	//读取磁力计的ADC值
	MPU6050_Raw_Data.Mag_X = values[6];
	MPU6050_Raw_Data.Mag_Y = values[7];
	MPU6050_Raw_Data.Mag_Z = values[8];
}

/**************************实现函数********************************************
*函数原型:	   void IMU_AHRSupdate
*功　　能:	 更新AHRS 更新四元数 
输入参数： 当前的测量值。
输出参数：没有
*******************************************************************************/
float Kp = 0.0002f;   // proportional gain governs rate of convergence to accelerometer/magnetometer
float Ki = 0.000f;  // integral gain governs rate of convergence of gyroscope biases

int count_init = 0;
float z_err_p = 0;
void IMU_AHRSupdate(void) {
    float norm;
    float hx, hy, hz, bx, bz;
    float vx, vy, vz, wx, wy, wz;
    float ex, ey, ez,halfT;
    float tempq0,tempq1,tempq2,tempq3;

    float q0q0 = q0*q0;
    float q0q1 = q0*q1;
    float q0q2 = q0*q2;
    float q0q3 = q0*q3;
    float q1q1 = q1*q1;
    float q1q2 = q1*q2;
    float q1q3 = q1*q3;
    float q2q2 = q2*q2;   
    float q2q3 = q2*q3;
    float q3q3 = q3*q3;   

	
	

	gx = mygetqval[3] * 0;
    gy = mygetqval[4] * 0;
    gz = mygetqval[5] * M_PI/180;
    ax = mygetqval[0] * 0;
    ay = mygetqval[1] * 0;
    az = 1;
    mx = mygetqval[6];
    my = mygetqval[7];
    mz = mygetqval[8];	
	
//	adjust.Mag_z = atan(my/mx);
	
	halfT =  0.001f;
//    now = TIM2->CNT;  //读取时间 单位是us   
//    if(now<lastUpdate)
//    {
//        halfT =  ((float)(now + (0xffffffff- lastUpdate)) / 2000000.0f);   //  uint 0.5s
//    }
//    else	
//    {
//        
//		halfT=((float)(now - lastUpdate) / 2000000.0f);
//    }
//    lastUpdate = now;	//更新时间
    //快速求平方根算法
    norm = invSqrt(ax*ax + ay*ay + az*az);       
    ax = ax * norm;
    ay = ay * norm;
    az = az * norm;
    //把加计的三维向量转成单位向量。
    norm = invSqrt(mx*mx + my*my + mz*mz);          
    mx = mx * norm;
    my = my * norm;
    mz = mz * norm; 
    // compute reference direction of flux
    hx = 2.0f*mx*(0.5f - q2q2 - q3q3) + 2.0f*my*(q1q2 - q0q3) + 2.0f*mz*(q1q3 + q0q2);
    hy = 2.0f*mx*(q1q2 + q0q3) + 2.0f*my*(0.5f - q1q1 - q3q3) + 2.0f*mz*(q2q3 - q0q1);
    hz = 2.0f*mx*(q1q3 - q0q2) + 2.0f*my*(q2q3 + q0q1) + 2.0f*mz*(0.5f - q1q1 - q2q2);         
    bx = sqrt((hx*hx) + (hy*hy));
    bz = hz; 
    // estimated direction of gravity and flux (v and w)
    vx = 2.0f*(q1q3 - q0q2);
    vy = 2.0f*(q0q1 + q2q3);
    vz = q0q0 - q1q1 - q2q2 + q3q3;
    wx = 2.0f*bx*(0.5f - q2q2 - q3q3) + 2.0f*bz*(q1q3 - q0q2);
    wy = 2.0f*bx*(q1q2 - q0q3) + 2.0f*bz*(q0q1 + q2q3);
    wz = 2.0f*bx*(q0q2 + q1q3) + 2.0f*bz*(0.5f - q1q1 - q2q2);  
    // error is sum of cross product between reference direction of fields and direction measured by sensors
    ex = (ay*vz - az*vy) + (my*wz - mz*wy);
    ey = (az*vx - ax*vz) + (mz*wx - mx*wz);
    ez = (ax*vy - ay*vx) + (mx*wy - my*wx);
	
	/*****************分割线***********************/
	yaw_angle_sum_gz -= ((mygetqval[5])/500);
	yaw_angle_sum_gz = yaw_angle_sum_gz >   180 ? yaw_angle_sum_gz - 360 : yaw_angle_sum_gz;
	yaw_angle_sum_gz = yaw_angle_sum_gz < - 180 ? yaw_angle_sum_gz + 360 : yaw_angle_sum_gz;

	
//	float a_err,a;
//	a = - (angle[0] - Yaw_Angle_Offset);
//	a = a>180?a-360:a;
//	a = a<-180?a+360:a;
//	adjust.deviation_last = a;
//	a_err = a - yaw_angle_sum_gz;
//		if(a_err>180)
//			a_err = 360 - a_err;
//		else if(a_err<-180)
//			a_err = -360 - a_err;
//	if(count_init++ > 500)
//	{
//		
//		Kp = 6.5f;
//		Ki = 0.001f;
//		if(adjust.deviation<20&&adjust.deviation>-20)
//			yaw_angle_sum_gz += adjust.deviation/500000;
//	//	limit = 0.001f;
//	}
//	else if(count_init <1000)
//	{	
//		
//		adjust.deviation_offset = a_err;
//		Yaw_Angle_Offset = angle[0];
//	}
//	adjust.deviation_last = adjust.deviation;
//	adjust.deviation = a_err - adjust.deviation_offset;
	
	/*****************分割线***********************/
    if(ex != 0.0f && ey != 0.0f && ez != 0.0f)
    {
//        	
//		//加入零位修正 以2000ms后稳定的数据作为偏差值使车起始方向为当前方向
		if(count_init < 2000)
		{
			count_init++;
			adjust.deviation_last = ez;
		}
		else
		{
			ez -= adjust.deviation_last;
//			exInt = exInt + ex * Ki * halfT;
//			eyInt = eyInt + ey * Ki * halfT;
			ezInt = ezInt + ez * Ki * halfT;
			// 用叉积误差来做PI修正陀螺零偏
//			gx = gx + Kp*ex + exInt;
//			gy = gy + Kp*ey + eyInt;
			gz = gz + Kp*ez + ezInt;
		}
    }
    // 四元数微分方程
    tempq0 = q0 + (-q1*gx - q2*gy - q3*gz)*halfT;
    tempq1 = q1 + (q0*gx + q2*gz - q3*gy)*halfT;
    tempq2 = q2 + (q0*gy - q1*gz + q3*gx)*halfT;
    tempq3 = q3 + (q0*gz + q1*gy - q2*gx)*halfT;  

    // 四元数规范化
    norm = invSqrt(tempq0*tempq0 + tempq1*tempq1 + tempq2*tempq2 + tempq3*tempq3);
    q0 = tempq0 * norm;
    q1 = tempq1 * norm;
    q2 = tempq2 * norm;
    q3 = tempq3 * norm;

}


/**************************实现函数********************************************
*函数原型:	   void IMU_getQ(float * q)
*功　　能:	 更新四元数 返回当前的四元数组值
输入参数： 将要存放四元数的数组首地址
输出参数：没有
*******************************************************************************/

void IMU_getQ(volatile float * q) {

    IMU_getValues(mygetqval);	 //获取原始数据,加速度计和磁力计是原始值，陀螺仪转换成了deg/s
    IMU_AHRSupdate();
    q[0] = q0; //返回当前值
    q[1] = q1;
    q[2] = q2;
    q[3] = q3;
}

/**************************实现函数********************************************
*函数原型:	   void IMU_getYawPitchRoll(float * angles)
*功　　能:	 更新四元数 返回当前解算后的姿态数据
输入参数： 将要存放姿态角的数组首地址
输出参数：没有
*******************************************************************************/
void IMU_getYawPitchRoll(volatile float * angles) 
{  
    // volatile float gx=0.0, gy=0.0, gz=0.0; //估计重力方向
    IMU_getQ(q); //更新全局四元数
    //四元数转换成欧拉角，经过三角函数计算即可
    angles[0] = -atan2(2 * q[1] * q[2] + 2 * q[0] * q[3], -2 * q[2]*q[2] - 2 * q[3] * q[3] + 1)* 180/M_PI; // yaw        -pi----pi
    angles[1] = -asin(-2 * q[1] * q[3] + 2 * q[0] * q[2])* 180/M_PI; // pitch    -pi/2    --- pi/2 
    angles[2] = atan2(2 * q[2] * q[3] + 2 * q[0] * q[1], -2 * q[1] * q[1] - 2 * q[2] * q[2] + 1)* 180/M_PI; // roll       -pi-----pi  
}
void Init_Quaternion()//根据测量数据，初始化q0,q1,q2.q3，从而加快收敛速度
{
//	int16_t hx,hy,hz;
//	HMC58X3_getlastValues(&hx,&hy,&hz);
//		if(hx<0 && hy <0)   //OK
//	{
//		if(fabs(hx/hy)>=1)
//		{
//			q0 = -0.005;
//			q1 = -0.199;
//			q2 = 0.979;
//			q3 = -0.0089;
//		}
//		else
//		{
//			q0 = -0.008;
//			q1 = -0.555;
//			q2 = 0.83;
//			q3 = -0.002;
//		}
//		
//	}
//	else if (hx<0 && hy > 0) //OK
//	{
//		if(fabs(hx/hy)>=1)   
//		{
//			q0 = 0.005;
//			q1 = -0.199;
//			q2 = -0.978;
//			q3 = 0.012;
//		}
//		else
//		{
//			q0 = 0.005;
//			q1 = -0.553;
//			q2 = -0.83;
//			q3 = -0.0023;
//		}
//		
//	}
//	else if (hx > 0 && hy > 0)   //OK
//	{
//		if(fabs(hx/hy)>=1)
//		{
//			q0 = 0.0012;
//			q1 = -0.978;
//			q2 = -0.199;
//			q3 = -0.005;
//		}
//		else
//		{
//			q0 = 0.0023;
//			q1 = -0.83;
//			q2 = -0.553;
//			q3 = 0.0023;
//		}
//		
//	}
//	else if (hx > 0 && hy < 0)     //OK
//	{
//		if(fabs(hx/hy)>=1)
//		{
//			q0 = 0.0025;
//			q1 = 0.978;
//			q2 = -0.199;
//			q3 = 0.008;			
//		}
//		else
//		{
//			q0 = 0.0025;
//			q1 = 0.83;
//			q2 = -0.56;
//			q3 = 0.0045;
//		}		
//	}
//	
//	//根据hx hy hz来判断q的值，取四个相近的值做逼近即可,初始值可以由欧拉角转换到四元数计算得到
	 
}

/**************************实现函数********************************************
*函数原型:	  void HMC58X3_getRaw(int16_t *x,int16_t *y,int16_t *z)
*功　　能:	   写HMC5883L的寄存器读取5883寄存器的值
输入参数：    reg  寄存器地址
			  val   要写入的值	
输出参数：  无
*******************************************************************************/
void HMC58X3_ReadData(u8 *vbuff) {   
	HMC_Read_Len(HMC_ADDR,HMC58X3_XM, 6, vbuff);   //读取到磁力计数据
}


/**************************实现函数********************************************
*函数原型:	   void  HMC58X3_newValues(int16_t x,int16_t y,int16_t z)
*功　　能:	   更新一组数据到FIFO数组
输入参数：  磁力计三个轴对应的ADC值
输出参数：  无
*******************************************************************************/
void  HMC58X3_newValues(int16_t x,int16_t y,int16_t z)
{
	uint8_t i = 0;
	int32_t sum=0;

	for(i=1;i<10;i++)
	{
		HMC5883_FIFO[0][i-1]=HMC5883_FIFO[0][i];
		HMC5883_FIFO[1][i-1]=HMC5883_FIFO[1][i];
		HMC5883_FIFO[2][i-1]=HMC5883_FIFO[2][i];
	}
	HMC5883_FIFO[0][9]= x;//将新的数据放置到 数据的最后面
	HMC5883_FIFO[1][9]= y;
	HMC5883_FIFO[2][9]= z;
	
	for(i=0;i<10;i++)//求当前数组的合，再取平均值
	{	
		 sum+=HMC5883_FIFO[0][i];
	}
	HMC5883_FIFO[0][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=HMC5883_FIFO[1][i];
	}
	HMC5883_FIFO[1][10]=sum/10;

	sum=0;
	for(i=0;i<10;i++){
		 sum+=HMC5883_FIFO[2][i];
	}
	HMC5883_FIFO[2][10]=sum/10;
	//以上全部为未校准数据
	if(MagMaxMinData.MinMagX>HMC5883_FIFO[0][10])
	{
		MagMaxMinData.MinMagX=(int16_t)HMC5883_FIFO[0][10];
	}
	if(MagMaxMinData.MinMagY>HMC5883_FIFO[1][10])
	{
		MagMaxMinData.MinMagY=(int16_t)HMC5883_FIFO[1][10];
	}
	if(MagMaxMinData.MinMagZ>HMC5883_FIFO[2][10])
	{
		MagMaxMinData.MinMagZ=(int16_t)HMC5883_FIFO[2][10];
	}

	if(MagMaxMinData.MaxMagX<HMC5883_FIFO[0][10])
	{
		MagMaxMinData.MaxMagX=(int16_t)HMC5883_FIFO[0][10];		
	}
	if(MagMaxMinData.MaxMagY<HMC5883_FIFO[1][10])
	{
		MagMaxMinData.MaxMagY = HMC5883_FIFO[1][10];
	}
	if(MagMaxMinData.MaxMagZ<HMC5883_FIFO[2][10])
	{
		MagMaxMinData.MaxMagZ=(int16_t)HMC5883_FIFO[2][10];
	}	
//	MagSavedCaliData.MagXOffset = -(MagMaxMinData.MinMagX + MagMaxMinData.MaxMagX)/2;
//	MagSavedCaliData.MagYOffset = -(MagMaxMinData.MinMagY + MagMaxMinData.MaxMagY)/2;
}


/**************************实现函数********************************************
*函数原型:	  void HMC58X3_getRaw(int16_t *x,int16_t *y,int16_t *z)
*功　　能:	   写HMC5883L的寄存器
输入参数：    reg  寄存器地址
			  val   要写入的值	
输出参数：  无
*******************************************************************************/
void HMC58X3_getRaw(int16_t *x,int16_t *y,int16_t *z) 
{
    HMC58X3_ReadData(&mpu_buf[14]);
    HMC58X3_newValues((((int16_t)mpu_buf[18] << 8) | mpu_buf[19]), -(((int16_t)mpu_buf[14] << 8) | mpu_buf[15]), ((int16_t)mpu_buf[16] << 8) | mpu_buf[17]);
    *x = HMC5883_FIFO[0][10];
    *y = HMC5883_FIFO[1][10];
    *z = HMC5883_FIFO[2][10];
}

/**************************实现函数********************************************
*函数原型:	  void HMC58X3_getValues(int16_t *x,int16_t *y,int16_t *z)
*功　　能:	   读取 磁力计的当前ADC值
输入参数：    三个轴对应的输出指针	
输出参数：  无
*******************************************************************************/
void HMC58X3_getlastValues(int16_t *x,int16_t *y,int16_t *z) 
{
    *x = HMC5883_FIFO[0][10];
    *y = HMC5883_FIFO[1][10]; 
    *z = HMC5883_FIFO[2][10]; 
}

/**************************实现函数********************************************
*函数原型:	  void HMC58X3_mgetValues(volatile float *arry)
*功　　能:	   读取 校正后的 磁力计ADC值
输入参数：    输出数组指针	
输出参数：  无
*******************************************************************************/
void HMC58X3_mgetValues(volatile float *arry) 
{
    int16_t xr,yr,zr;
    HMC58X3_getRaw(&xr, &yr, &zr);
    arry[0]= HMC5883_lastx=((float)(xr + MagSavedCaliData.MagXOffset)) * MagSavedCaliData.MagXScale;
    arry[1]= HMC5883_lasty=((float)(yr + MagSavedCaliData.MagYOffset)) * MagSavedCaliData.MagYScale;
    arry[2]= HMC5883_lastz=((float)(zr + MagSavedCaliData.MagZOffset)) * MagSavedCaliData.MagZScale;
}




void GetTheFinal()
{
	MPU6050_Real_Data.Gyro_X = mygetqval[3];
	MPU6050_Real_Data.Gyro_Y = -mygetqval[4];
	MPU6050_Real_Data.Gyro_Z = mygetqval[5];

	yaw_angle = angle[0];  //yaw轴角度
	pitch_angle = angle[1];
    roll_angle = angle[2];
}
void EXTI0_IRQHandler(void)         //中断频率1KHz
{   
    if(EXTI_GetITStatus(EXTI_Line0) != RESET)
    {    
        EXTI_ClearFlag(EXTI_Line0);          
        EXTI_ClearITPendingBit(EXTI_Line0);
        //读取原始数据
        MPU6050_is_DRY = 1;   //mpu6050中断标志
        GetTheFinal();//读取姿态数据,数据已经处理成连续方式	
    }
}
void EXTI1_IRQHandler(void)         //中断频率1KHz
{   
    if(EXTI_GetITStatus(EXTI_Line1) != RESET)
    {    
        EXTI_ClearFlag(EXTI_Line1);          
        EXTI_ClearITPendingBit(EXTI_Line1);
        //读取原始数据
        HMC5883_is_DRY = 1;   //mpu6050中断标志
        GetTheFinal();//读取姿态数据,数据已经处理成连续方式	
    }
}
//IIC连续读
//addr:器件地址
//reg:要读取的寄存器地址
//len:要读取的长度
//buf:读取到的数据存储区
//返回值:0,正常
//    其他,错误代码
u8 MPU_Read_Len(u8 addr,u8 reg,u8 len,u8 *buf)
{ 
 	MPU_IIC_Start(); 
	MPU_IIC_Send_Byte((addr<<1)|0);//发送器件地址+写命令	
	if(MPU_IIC_Wait_Ack())	//等待应答
	{
		MPU_IIC_Stop();		 
		return 1;		
	}
    MPU_IIC_Send_Byte(reg);	//写寄存器地址
    MPU_IIC_Wait_Ack();		//等待应答
    MPU_IIC_Start();
		MPU_IIC_Send_Byte((addr<<1)|1);//发送器件地址+读命令	
    MPU_IIC_Wait_Ack();		//等待应答 
	while(len)
	{
		if(len==1)*buf=MPU_IIC_Read_Byte(0);//读数据,发送nACK 
		else *buf=MPU_IIC_Read_Byte(1);		//读数据,发送ACK  
		len--;
		buf++; 
	}    
    MPU_IIC_Stop();	//产生一个停止条件 
	return 0;	
}
//IIC写一个字节 
//reg:寄存器地址
//data:数据
//返回值:0,正常
//    其他,错误代码
u8 MPU_Write_Byte(u8 reg,u8 data) 				 
{ 
    MPU_IIC_Start(); 
	MPU_IIC_Send_Byte((MPU_ADDR<<1)|0);//发送器件地址+写命令	
	if(MPU_IIC_Wait_Ack())	//等待应答
	{
		MPU_IIC_Stop();		 
		return 1;		
	}
    MPU_IIC_Send_Byte(reg);	//写寄存器地址
    MPU_IIC_Wait_Ack();		//等待应答 
	MPU_IIC_Send_Byte(data);//发送数据
	if(MPU_IIC_Wait_Ack())	//等待ACK
	{
		MPU_IIC_Stop();	 
		return 1;		 
	}		 
    MPU_IIC_Stop();	 
	return 0;
}
//IIC读一个字节 
//reg:寄存器地址 
//返回值:读到的数据
u8 MPU_Read_Byte(u8 reg)
{
	u8 res;
    MPU_IIC_Start(); 
	MPU_IIC_Send_Byte((MPU_ADDR<<1)|0);//发送器件地址+写命令	
	MPU_IIC_Wait_Ack();		//等待应答 
    MPU_IIC_Send_Byte(reg);	//写寄存器地址
    MPU_IIC_Wait_Ack();		//等待应答
    MPU_IIC_Start();
	MPU_IIC_Send_Byte((MPU_ADDR<<1)|1);//发送器件地址+读命令	
    MPU_IIC_Wait_Ack();		//等待应答 
	res=MPU_IIC_Read_Byte(0);//读取数据,发送nACK 
    MPU_IIC_Stop();			//产生一个停止条件 
	return res;		
}


//初始化IIC
void MPU_IIC_Init(void)
{			
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);//使能GPIOB时钟

	//GPIOB8,B9初始化设置
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//普通输出模式
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉
	GPIO_Init(GPIOC, &GPIO_InitStructure);//初始化
	MPU_IIC_SCL=1;
	MPU_IIC_SDA=1;
}
//产生IIC起始信号
void MPU_IIC_Start(void)
{
	MPU_SDA_OUT();     //sda线输出
	MPU_IIC_SDA=1;	  	  
	MPU_IIC_SCL=1;
	delay_us(4);
 	MPU_IIC_SDA=0;//START:when CLK is high,DATA change form high to low 
	delay_us(4);
	MPU_IIC_SCL=0;//钳住I2C总线，准备发送或接收数据 
}	  
//产生IIC停止信号
void MPU_IIC_Stop(void)
{
	MPU_SDA_OUT();//sda线输出
	MPU_IIC_SCL=0;
	MPU_IIC_SDA=0;//STOP:when CLK is high DATA change form low to high
 	delay_us(4);
	MPU_IIC_SCL=1; 
	MPU_IIC_SDA=1;//发送I2C总线结束信号
	delay_us(4);							   	
}
//等待应答信号到来
//返回值：1，接收应答失败
//        0，接收应答成功
u8 MPU_IIC_Wait_Ack(void)
{
	u8 ucErrTime=0;
	MPU_SDA_IN();      //SDA设置为输入  
	MPU_IIC_SDA=1;delay_us(1);	   
	MPU_IIC_SCL=1;delay_us(1);	 
	while(MPU_READ_SDA)
	{
		ucErrTime++;
		if(ucErrTime>250)
		{
			MPU_IIC_Stop();
			return 1;
		}
	}
	MPU_IIC_SCL=0;//时钟输出0 	   
	return 0;  
} 
//产生ACK应答
void MPU_IIC_Ack(void)
{
	MPU_IIC_SCL=0;
	MPU_SDA_OUT();
	MPU_IIC_SDA=0;
	delay_us(2);
	MPU_IIC_SCL=1;
	delay_us(2);
	MPU_IIC_SCL=0;
}
//不产生ACK应答		    
void MPU_IIC_NAck(void)
{
	MPU_IIC_SCL=0;
	MPU_SDA_OUT();
	MPU_IIC_SDA=1;
	delay_us(2);
	MPU_IIC_SCL=1;
	delay_us(2);
	MPU_IIC_SCL=0;
}					 				     
//IIC发送一个字节
//返回从机有无应答
//1，有应答
//0，无应答			  
void MPU_IIC_Send_Byte(u8 txd)
{                        
    u8 t;   
	MPU_SDA_OUT(); 	    
    MPU_IIC_SCL=0;//拉低时钟开始数据传输
    for(t=0;t<8;t++)
    {              
        MPU_IIC_SDA=(txd&0x80)>>7;
        txd<<=1; 	  
		delay_us(2);   //对TEA5767这三个延时都是必须的
		MPU_IIC_SCL=1;
		delay_us(2); 
		MPU_IIC_SCL=0;	
		delay_us(2);
    }	 
} 	    
//读1个字节，ack=1时，发送ACK，ack=0，发送nACK   
u8 MPU_IIC_Read_Byte(unsigned char ack)
{
	unsigned char i,receive=0;
	MPU_SDA_IN();//SDA设置为输入
    for(i=0;i<8;i++ )
	{
        MPU_IIC_SCL=0; 
        delay_us(2);
		MPU_IIC_SCL=1;
        receive<<=1;
        if(MPU_READ_SDA)receive++;   
		delay_us(1); 
    }					 
    if (!ack)
        MPU_IIC_NAck();//发送nACK
    else
        MPU_IIC_Ack(); //发送ACK   
    return receive;
}



//IIC连续读
//addr:器件地址
//reg:要读取的寄存器地址
//len:要读取的长度
//buf:读取到的数据存储区
//返回值:0,正常
//    其他,错误代码
u8 HMC_Read_Len(u8 addr,u8 reg,u8 len,u8 *buf)
{ 
 	HMC_IIC_Start(); 
	HMC_IIC_Send_Byte(addr|0);//发送器件地址+写命令	
	if(HMC_IIC_Wait_Ack())	//等待应答
	{
		HMC_IIC_Stop();		 
		return 1;		
	}
    HMC_IIC_Send_Byte(reg);	//写寄存器地址
    HMC_IIC_Wait_Ack();		//等待应答
    HMC_IIC_Start();
	HMC_IIC_Send_Byte(addr|1);//发送器件地址+读命令	
    HMC_IIC_Wait_Ack();		//等待应答 
	while(len)
	{
		if(len==1)*buf=HMC_IIC_Read_Byte(0);//读数据,发送nACK 
		else *buf=HMC_IIC_Read_Byte(1);		//读数据,发送ACK  
		len--;
		buf++; 
	}    
    HMC_IIC_Stop();	//产生一个停止条件 
	return 0;	
}
//IIC写一个字节 
//reg:寄存器地址
//data:数据
//返回值:0,正常
//    其他,错误代码
u8 HMC_Write_Byte(u8 reg,u8 data) 				 
{ 
    HMC_IIC_Start(); 
	HMC_IIC_Send_Byte(HMC_ADDR|0);//发送器件地址+写命令	
	if(HMC_IIC_Wait_Ack())	//等待应答
	{
		HMC_IIC_Stop();		 
		return 1;		
	}
    HMC_IIC_Send_Byte(reg);	//写寄存器地址		
    HMC_IIC_Wait_Ack();		//等待应答 
	HMC_IIC_Send_Byte(data);//发送数据
	if(HMC_IIC_Wait_Ack())	//等待ACK
	{
		HMC_IIC_Stop();	 
		return 1;		 
	}		 
    HMC_IIC_Stop();	 
	return 0;
}
//IIC读一个字节 
//reg:寄存器地址 
//返回值:读到的数据
u8 HMC_Read_Byte(u8 reg)
{
	u8 res;
    HMC_IIC_Start(); 
	HMC_IIC_Send_Byte(HMC_ADDR|0);//发送器件地址+写命令	
	HMC_IIC_Wait_Ack();		//等待应答 
    HMC_IIC_Send_Byte(reg);	//写寄存器地址
    HMC_IIC_Wait_Ack();		//等待应答
    HMC_IIC_Start();
	HMC_IIC_Send_Byte(HMC_ADDR|1);//发送器件地址+读命令	
    HMC_IIC_Wait_Ack();		//等待应答 
	res=HMC_IIC_Read_Byte(0);//读取数据,发送nACK 
    HMC_IIC_Stop();			//产生一个停止条件 
	return res;		
}


//初始化IIC
void HMC_IIC_Init(void)
{			
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);//使能GPIOB时钟

	//GPIOB8,B9初始化设置
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//普通输出模式
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉
	GPIO_Init(GPIOD, &GPIO_InitStructure);//初始化
	HMC_IIC_SCL=1;
	HMC_IIC_SDA=1;
}
//产生IIC起始信号
void HMC_IIC_Start(void)
{
	HMC_SDA_OUT();     //sda线输出
	HMC_IIC_SDA=1;	  	  
	HMC_IIC_SCL=1;
	delay_us(4);
 	HMC_IIC_SDA=0;//START:when CLK is high,DATA change form high to low 
	delay_us(4);
	HMC_IIC_SCL=0;//钳住I2C总线，准备发送或接收数据 
}	  
//产生IIC停止信号
void HMC_IIC_Stop(void)
{
	HMC_SDA_OUT();//sda线输出
	HMC_IIC_SCL=0;
	HMC_IIC_SDA=0;//STOP:when CLK is high DATA change form low to high
 	delay_us(4);
	HMC_IIC_SCL=1; 
	HMC_IIC_SDA=1;//发送I2C总线结束信号
	delay_us(4);							   	
}
//等待应答信号到来
//返回值：1，接收应答失败
//        0，接收应答成功
u8 HMC_IIC_Wait_Ack(void)
{
	u8 ucErrTime=0;
	HMC_SDA_IN();      //SDA设置为输入  
	HMC_IIC_SDA=1;delay_us(1);	   
	HMC_IIC_SCL=1;delay_us(1);	 
	while(HMC_READ_SDA)
	{
		ucErrTime++;
		if(ucErrTime>250)
		{
			HMC_IIC_Stop();
			return 1;
		}
	}
	HMC_IIC_SCL=0;//时钟输出0 	   
	return 0;  
} 
//产生ACK应答
void HMC_IIC_Ack(void)
{
	HMC_IIC_SCL=0;
	HMC_SDA_OUT();
	HMC_IIC_SDA=0;
	delay_us(2);
	HMC_IIC_SCL=1;
	delay_us(2);
	HMC_IIC_SCL=0;
}
//不产生ACK应答		    
void HMC_IIC_NAck(void)
{
	HMC_IIC_SCL=0;
	HMC_SDA_OUT();
	HMC_IIC_SDA=1;
	delay_us(2);
	HMC_IIC_SCL=1;
	delay_us(2);
	HMC_IIC_SCL=0;
}					 				     
//IIC发送一个字节
//返回从机有无应答
//1，有应答
//0，无应答			  
void HMC_IIC_Send_Byte(u8 txd)
{                        
    u8 t;   
	HMC_SDA_OUT(); 	    
    HMC_IIC_SCL=0;//拉低时钟开始数据传输
    for(t=0;t<8;t++)
    {              
        HMC_IIC_SDA=(txd&0x80)>>7;
        txd<<=1; 	  
		delay_us(2);   //对TEA5767这三个延时都是必须的
		HMC_IIC_SCL=1;
		delay_us(2); 
		HMC_IIC_SCL=0;	
		delay_us(2);
    }	 
} 	    
//读1个字节，ack=1时，发送ACK，ack=0，发送nACK   
u8 HMC_IIC_Read_Byte(unsigned char ack)
{
	unsigned char i,receive=0;
	HMC_SDA_IN();//SDA设置为输入
    for(i=0;i<8;i++ )
	{
        HMC_IIC_SCL=0; 
        delay_us(2);
		HMC_IIC_SCL=1;
        receive<<=1;
        if(HMC_READ_SDA)receive++;   
		delay_us(1); 
    }					 
    if (!ack)
        HMC_IIC_NAck();//发送nACK
    else
        HMC_IIC_Ack(); //发送ACK   
    return receive;
}
