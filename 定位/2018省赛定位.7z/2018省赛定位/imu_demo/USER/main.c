#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "imu.h"
#include "Ab_fusion.h"
#include "can.h"
#include "hc05.h"
#include "usart.h"
extern Enconder enconderA;
void TIM2_Configuration(void)
{
    TIM_TimeBaseInitTypeDef tim;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
    tim.TIM_Period = 0xFFFFFFFF;
    tim.TIM_Prescaler = 84 - 1;	 //1M քʱד  
    tim.TIM_ClockDivision = TIM_CKD_DIV1;	
    tim.TIM_CounterMode = TIM_CounterMode_Up;  
    TIM_ARRPreloadConfig(TIM2, ENABLE);	
    TIM_TimeBaseInit(TIM2, &tim);

    TIM_Cmd(TIM2,ENABLE);	
}
void TIM6_Configuration(void)
{
    TIM_TimeBaseInitTypeDef  tim;
    NVIC_InitTypeDef         nvic;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,ENABLE);
    
    nvic.NVIC_IRQChannel = TIM6_DAC_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 1;
    nvic.NVIC_IRQChannelSubPriority = 0;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);

    tim.TIM_Prescaler = 84-1;        //84M internal clock
    tim.TIM_CounterMode = TIM_CounterMode_Up;
    tim.TIM_ClockDivision = TIM_CKD_DIV1;
    tim.TIM_Period = 2000;  //1ms,1000Hz
    TIM_TimeBaseInit(TIM6,&tim);
}

void TIM6_Start(void)
{
    TIM_Cmd(TIM6, ENABLE);	 
    TIM_ITConfig(TIM6, TIM_IT_Update,ENABLE);
    TIM_ClearFlag(TIM6, TIM_FLAG_Update);	
}

int main(void)
{
	delay_init(168);
	uart_init(115200);
	//while(IMU_Configure());
	posSys_Configure();
	CAN_Configure();
	TIM2_Configuration();
	TIM6_Configuration();
	TIM6_Start();
	while(1)
    {
		
		printf("X: %d\r\n  ", enconderA.deff);
//		printf("Y: %.1f  \r\n\r\n", POS.pos_Y);
//		printf("A: %.1f  ", POS.angle_now);
//		
//		printf("Ar: %.1f  ", -angle[0]);
//		printf("W: %.1f \n\r", MPU6050_Real_Data.Gyro_Z);
		delay_ms(500);
	}
}

void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2,TIM_IT_Update)!= RESET) 
	{
		 TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
		 TIM_ClearFlag(TIM2, TIM_FLAG_Update);
	}
} 

int64_t ms_count = 0;

void TIM6_DAC_IRQHandler(void)  
{
	
    if (TIM_GetITStatus(TIM6,TIM_IT_Update)!= RESET) 
	{
		TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
		TIM_ClearFlag(TIM6, TIM_FLAG_Update);
		IMU_getYawPitchRoll(angle);
		
		if(ms_count % 2)
		{
			doFusion();			
			Send_Angle_Data(MPU6050_Real_Data.Gyro_Z,yaw_angle);
		}
		else if(ms_count % 100)
		{

		}
		ms_count++;
    }
}



