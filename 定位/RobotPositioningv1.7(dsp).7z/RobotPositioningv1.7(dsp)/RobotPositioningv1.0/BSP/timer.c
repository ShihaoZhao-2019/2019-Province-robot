#include "main.h"

u8 doing_offset = 1;
u8 offset_flag = 0;

u8 time_1ms = 0;
void TIM6_Configure(void)
{
    TIM_TimeBaseInitTypeDef  tim;
    NVIC_InitTypeDef         nvic;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,ENABLE);
    
    nvic.NVIC_IRQChannel = TIM6_DAC_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 0;
    nvic.NVIC_IRQChannelSubPriority = 0;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);
    tim.TIM_Prescaler = 84-1;        //84M internal clock
    tim.TIM_CounterMode = TIM_CounterMode_Up;
    tim.TIM_ClockDivision = TIM_CKD_DIV1;
    tim.TIM_Period = 1000;  //1ms,1000Hz
    TIM_TimeBaseInit(TIM6,&tim);
}

void TIM6_Start(void)
{
    TIM_Cmd(TIM6, ENABLE);	 
    TIM_ITConfig(TIM6, TIM_IT_Update,ENABLE);
    TIM_ClearFlag(TIM6, TIM_FLAG_Update);	
}
void TIM6_Stop(void)
{
    TIM_Cmd(TIM6, DISABLE);	 
    TIM_ITConfig(TIM6, TIM_IT_Update,DISABLE);
}

uint64_t time6_ms = 0;

void TIM6_DAC_IRQHandler(void)  
{
    if (TIM_GetITStatus(TIM6,TIM_IT_Update)!= RESET) 
	{
		TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
		TIM_ClearFlag(TIM6, TIM_FLAG_Update);
		time6_ms++;
		ins_task();
		if((offset_ok == 0) && (doing_offset == 1)) 
		{
			cali_gyro_hook();
		}
		else if(offset_ok == 1) 
		{
			offset_flag = 1;
		}			
		if(offset_flag == 1)       //���̡���̨��������
		{
//			if(time6_ms % 2 == 0)
			{
				doFusion();//λ�ø���
				
				send_mpu_data((float)yaw_angle,(float)ins_gyro[2]);//CAN���ͽǶȺͽ��ٶ�
				send_pos_data((float)POS.pos_X,(float)POS.pos_Y);
			}	
				if((time6_ms % 500 == 0) && (time6_ms % 1000 != 0))
					LED1_ON;
				else if(time6_ms % 1000 == 0)
					LED1_OFF;
		}
		else 
		{
			send_mpu_data(6.0f, 6.0f);
			send_pos_data(6.0f, 6.0f);
			LED1_ON;
		}
		
   }
	

}


