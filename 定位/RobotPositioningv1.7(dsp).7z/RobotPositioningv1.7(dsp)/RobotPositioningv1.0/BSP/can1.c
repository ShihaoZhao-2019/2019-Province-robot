#include "main.h"

/*----CAN1_TX------PA12----*/
/*----CAN1_RX------PA11----*/

void CAN1_Configure(void)						//can1���߳�ʼ��
{
    CAN_InitTypeDef        can;
    CAN_FilterInitTypeDef  can_filter;
    GPIO_InitTypeDef       gpio;
    NVIC_InitTypeDef       nvic;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource11, GPIO_AF_CAN1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource12, GPIO_AF_CAN1);

    gpio.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12;
    gpio.GPIO_Mode = GPIO_Mode_AF;
    GPIO_Init(GPIOA, &gpio);

    nvic.NVIC_IRQChannel = CAN1_RX0_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 2;
    nvic.NVIC_IRQChannelSubPriority = 2;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);

    nvic.NVIC_IRQChannel = CAN1_TX_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 1;
    nvic.NVIC_IRQChannelSubPriority = 1;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);    

    CAN_DeInit(CAN1);
    CAN_StructInit(&can);

    can.CAN_TTCM = DISABLE;
    can.CAN_ABOM = DISABLE;
    can.CAN_AWUM = DISABLE;
    can.CAN_NART = DISABLE;
    can.CAN_RFLM = DISABLE;
    can.CAN_TXFP = ENABLE;
    can.CAN_Mode = CAN_Mode_Normal;
    can.CAN_SJW  = CAN_SJW_1tq;
    can.CAN_BS1 = CAN_BS1_9tq;
    can.CAN_BS2 = CAN_BS2_4tq;
    can.CAN_Prescaler = 3;   //CAN BaudRate 42/(1+9+4)/3=1Mbps
    CAN_Init(CAN1, &can);

    can_filter.CAN_FilterNumber=0;
    can_filter.CAN_FilterMode=CAN_FilterMode_IdMask;
    can_filter.CAN_FilterScale=CAN_FilterScale_32bit;
    can_filter.CAN_FilterIdHigh=0x0000;
    can_filter.CAN_FilterIdLow=0x0000;
    can_filter.CAN_FilterMaskIdHigh=0x0000;
    can_filter.CAN_FilterMaskIdLow=0x0000;
    can_filter.CAN_FilterFIFOAssignment=0;//the message which pass the filter save in fifo0
    can_filter.CAN_FilterActivation=ENABLE;
    CAN_FilterInit(&can_filter);

    CAN_ITConfig(CAN1,CAN_IT_FMP0,ENABLE);
    CAN_ITConfig(CAN1,CAN_IT_TME,ENABLE);
}


void CAN1_TX_IRQHandler(void) //CAN TX
{
    if (CAN_GetITStatus(CAN1,CAN_IT_TME)!= RESET) 
	{
		CAN_ClearITPendingBit(CAN1,CAN_IT_TME);
    }
}

void CAN1_RX0_IRQHandler(void)
{   
	CanRxMsg rx_message;	
    if (CAN_GetITStatus(CAN1,CAN_IT_FMP0)!= RESET)
	{
        CAN_ClearITPendingBit(CAN1, CAN_IT_FF0);
		CAN_ClearFlag(CAN1, CAN_FLAG_FF0); 
		CAN_Receive(CAN1, CAN_FIFO0, &rx_message);
		Can1ReceiveMsgProcess(&rx_message);
    }
}





uint64_t detection_sending_flag = 0;
void send_mpu_data(float yaw, float gz)
{
	
	  CanTxMsg tx_message;
    tx_message.StdId = 0x103;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
		

    tx_message.Data[0] = (uint8_t)((*(uint32_t*)&yaw) >> 24);
    tx_message.Data[1] = (uint8_t)((*(uint32_t*)&yaw) >> 16);
    tx_message.Data[2] = (uint8_t)((*(uint32_t*)&yaw) >> 8);
    tx_message.Data[3] = (uint8_t)(*(uint32_t*)&yaw);
	
    tx_message.Data[4] = (uint8_t)((*(uint32_t*)&gz) >> 24);
    tx_message.Data[5] = (uint8_t)((*(uint32_t*)&gz) >> 16);
    tx_message.Data[6] = (uint8_t)((*(uint32_t*)&gz) >> 8);
    tx_message.Data[7] = (uint8_t)(*(uint32_t*)&gz);
    CAN_Transmit(CAN1,&tx_message);		
		detection_sending_flag ++;
		if(offset_ok)
		{
			if((detection_sending_flag % 500 == 0) && (detection_sending_flag % 1000 != 0))
				LED0_ON;
			else if(detection_sending_flag % 1000 == 0)
				LED0_OFF;
		}
		else LED0_ON;

}
void send_pos_data(float x, float y)
{
		CanTxMsg tx_message;
    tx_message.StdId = 0x105;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
		
    tx_message.Data[0] = (uint8_t)((*(uint32_t*)&x) >> 24);
    tx_message.Data[1] = (uint8_t)((*(uint32_t*)&x) >> 16);
    tx_message.Data[2] = (uint8_t)((*(uint32_t*)&x) >> 8);
    tx_message.Data[3] = (uint8_t)(*(uint32_t*)&x);
	
    tx_message.Data[4] = (uint8_t)((*(uint32_t*)&y) >> 24);
    tx_message.Data[5] = (uint8_t)((*(uint32_t*)&y) >> 16);
    tx_message.Data[6] = (uint8_t)((*(uint32_t*)&y) >> 8);
    tx_message.Data[7] = (uint8_t)(*(uint32_t*)&y);
    CAN_Transmit(CAN1,&tx_message);	
}

void Can1ReceiveMsgProcess(CanRxMsg *message)
{
	switch(message->StdId)
	{
		case 0x104:			getPosData(message);						break;

	}
}
void getPosData(CanRxMsg * msg)
{
	res_pos.last_posx = res_pos.posx;
	res_pos.last_posy = res_pos.posy;
	for (int i = 0;i < 2;i++)
	{
		res_pos.r_posx = res_pos.r_posx << 8 |  msg->Data[i];
		res_pos.r_posy = res_pos.r_posy << 8 |  msg->Data[2 + i];
		(*(uint16_t *)&res_pos.flag) = (*(uint16_t *)&res_pos.flag) << 8 |  msg->Data[4 + i];
	}	
	if(fabs(res_pos.last_posx - res_pos.r_posx) >= 300.0f)
		res_pos.posx = res_pos.last_posx;
	else 
		res_pos.posx = res_pos.r_posx;
	if(fabs(res_pos.last_posy - res_pos.r_posy) >= 300.0f)
		res_pos.posy = res_pos.last_posy;
	else 
		res_pos.posy = res_pos.r_posy;
	
	if(	res_pos.flag == 1)
	{
			POS.pos_X = res_pos.r_posx;
			POS.pos_Y = res_pos.r_posy;
	}
}
