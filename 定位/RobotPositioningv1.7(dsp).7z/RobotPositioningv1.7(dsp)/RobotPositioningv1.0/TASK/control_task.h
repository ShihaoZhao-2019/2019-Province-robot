#ifndef _CONTROL_TASK_H_
#define _CONTROL_TASK_H_

void control_task(void);



#endif
