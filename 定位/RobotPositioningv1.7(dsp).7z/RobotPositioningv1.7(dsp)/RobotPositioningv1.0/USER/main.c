#include "main.h"

int main(void)
{
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
		delay_init(168);	
		while(IMU_Configure()){}
		IMU_INT_Configure();
//		IMU_EXIT_START();

		LED_Init();
		posSys_Configure();
		delay_ms(2000);	
		CAN1_Configure();
		uart_init(115200);
		TIM6_Configure();
		TIM6_Start();
		

	while(1)
	{
		
//		printf("\r\n X: %f    Y: %f   A: %f     C: %d", POS.pos_X, POS.pos_Y, t_angle[2], count_time);
//		  delay_ms(500);
//			printf("hello world1\r\n");
	}
}
