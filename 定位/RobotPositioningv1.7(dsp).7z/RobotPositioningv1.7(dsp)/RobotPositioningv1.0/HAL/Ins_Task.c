#include "main.h"


static fp32 INS_gyro[3] = {0.0f, 0.0f, 0.0f};
static fp32 INS_accel[3] = {0.0f, 0.0f, 0.0f};
static fp32 INS_mag[3] = {0.0f, 0.0f, 0.0f};
static fp32 gyro_cali_offset[3] ={0.0f, 0.0f, 0.0f};
uint16_t count_time = 0;
static fp32 Gyro_Offset[3] = {0.0f, 0.0f, 0.0f};            //��������Ư
static fp32 Gyro_Scale_Factor[3][3] = {IMU_BOARD_INSTALL_SPIN_MATRIX}; //������У׼���Զ�

u8 offset_ok = 0;
int8_t cali_gyro_hook(void)
{
	imu_cali_t local_cali_t;

	INS_cali_gyro(local_cali_t.scale, local_cali_t.offset, &count_time);
	if (count_time > GYRO_CALIBRATE_TIME)
	{
		count_time = 0;
		OFFSET_Buffer[0] = local_cali_t.offset[0];
		OFFSET_Buffer[1] = local_cali_t.offset[1];
		OFFSET_Buffer[2] = local_cali_t.offset[2];
		flash_write();
		offset_ok = 1;
		return 1;
	}
	else
	{
		offset_ok = 0;
		return 0;
	}
	
}


void INS_cali_gyro(fp32 cali_scale[3], fp32 cali_offset[3], uint16_t *time_count)
{
    if (1)
    {
        if( *time_count == 0)
        {
            Gyro_Offset[0] = gyro_cali_offset[0];
            Gyro_Offset[1] = gyro_cali_offset[1];
            Gyro_Offset[2] = gyro_cali_offset[2];
        }
        gyro_offset(Gyro_Offset, INS_gyro, 0, time_count);

        cali_offset[0] = Gyro_Offset[0];
        cali_offset[1] = Gyro_Offset[1];
        cali_offset[2] = Gyro_Offset[2];
    }
}


void gyro_offset(float gyro_offset[3], float gyro[3], uint8_t imu_status, uint16_t *offset_time_count)
{

		gyro_offset[0] = gyro_offset[0] - GYRO_OFFSET_KP * gyro[0];
		gyro_offset[1] = gyro_offset[1] - GYRO_OFFSET_KP * gyro[1];
		gyro_offset[2] = gyro_offset[2] - GYRO_OFFSET_KP * gyro[2];
		(*offset_time_count)++;

}


void INS_set_cali_gyro(fp32 cali_scale[3], fp32 cali_offset[6])
{
    gyro_cali_offset[0]  = cali_offset[0];
    gyro_cali_offset[1]  = cali_offset[1];
    gyro_cali_offset[2]  = cali_offset[2];
	
	if((fabs(gyro_cali_offset[0]) >= 32767.0f) || (fabs(gyro_cali_offset[1]) >= 32767.0f) || (fabs(gyro_cali_offset[2]) >= 32767.0f))
	{
		gyro_cali_offset[0] = gyro_cali_offset[1] = gyro_cali_offset[2] = 0.0f;
	}

}

void IMU_Cali_Slove(fp32 gyro[3], fp32 accel[3], fp32 mag[3], mpu6050_real_data_t *mpu6050)
{
    for (uint8_t i = 0; i < 3; i++)
    {
        gyro[i] = mpu6050->gyro[0] * Gyro_Scale_Factor[i][0] + mpu6050->gyro[1] * Gyro_Scale_Factor[i][1] + mpu6050->gyro[2] * Gyro_Scale_Factor[i][2] + Gyro_Offset[i];
    }
}
float ins_gyro[3];
volatile float t_angle[3] = {0.0f, 0.0f, 0.0f};
void ins_task(void)
{
	
	Get_mpu_data();
	IMU_Cali_Slove(INS_gyro, INS_accel, INS_mag, &mpu6050_data);
	
	static uint16_t start_gyro_cali_time = 0;
	if(start_gyro_cali_time == 0)
	{		
			Gyro_Offset[0] = gyro_cali_offset[0];
			Gyro_Offset[1] = gyro_cali_offset[1];
			Gyro_Offset[2] = gyro_cali_offset[2];
			start_gyro_cali_time++;
	}
										
//	for(int i = 0; i < 3; i++)
//	{
		ins_gyro[2] = INS_gyro[2] * -57.3f;
//	}
	if(offset_ok)
		t_angle[2] += ins_gyro[2] / 987.5f;   //yaw
}
