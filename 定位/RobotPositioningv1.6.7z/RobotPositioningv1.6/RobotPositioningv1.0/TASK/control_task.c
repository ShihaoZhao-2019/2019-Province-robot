#include "main.h"

void control_task() 
{

	chassis_out_update();

}
