# ifndef INS_H_
# define INS_H_
#include "stm32f4xx.h"
#include "imu.h"
typedef float fp32;

#define GYRO_CALIBRATE_TIME 20000
#define GYRO_OFFSET_KP 0.0003f
#define GYRO_SEN 0.0005326322180158476492076f					// 1 / (32.8 * 57.3) 
#define IMU_BOARD_INSTALL_SPIN_MATRIX                           \
                                        { 0.0f, 1.0f, 0.0f},    \
                                        {-1.0f, 0.0f, 0.0f},    \
                                        { 0.0f, 0.0f, 1.0f}    \
//static fp32 Gyro_Scale_Factor[3][3] = {IMU_BOARD_INSTALL_SPIN_MATRIX}; //������У׼���Զ�

typedef struct 
{
    fp32 offset[3]; //x,y,z
    fp32 scale[3];  //x,y,z
} imu_cali_t;

int8_t cali_gyro_hook(void);
void INS_set_cali_gyro(fp32 cali_scale[3], fp32 cali_offset[6]);
void gyro_offset(float gyro_offset[3], float gyro[3], uint8_t imu_status, uint16_t *offset_time_count);


void INS_cali_gyro(fp32 cali_scale[3], fp32 cali_offset[3], uint16_t *time_count);
void IMU_Cali_Slove(fp32 gyro[3], fp32 accel[3], fp32 mag[3], mpu6050_real_data_t *mpu6050);

void ins_task(void);
extern u8 offset_ok;
extern float ins_gyro[3];
extern volatile float t_angle[3];
extern float angle_cali;
extern uint16_t count_time;
# endif
