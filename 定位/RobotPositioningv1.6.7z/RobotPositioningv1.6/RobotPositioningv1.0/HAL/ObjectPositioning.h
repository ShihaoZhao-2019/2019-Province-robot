#ifndef _POSITION
#define _POSITION

#include "sys.h"
#include "math.h"
#define RAD_45 (double)0.7853982


typedef struct pos__
{
    float angle_now;
    float angle_last;
    float angle_reference;
    float pos_X;
    float pos_Y;
    int ender_A;
    int ender_B;
}Position;

typedef struct{
	int16_t posx;
	int16_t posy;
	int16_t last_posx;
	int16_t last_posy;
	int16_t r_posx;
	int16_t r_posy;
	int16_t flag;
}RES_POS;


extern Position POS;

void doFusion(void);
float getAngleAVG(void);
float setAngleReference(void);
double Angle2Radian(float w);
extern RES_POS res_pos;
#endif


