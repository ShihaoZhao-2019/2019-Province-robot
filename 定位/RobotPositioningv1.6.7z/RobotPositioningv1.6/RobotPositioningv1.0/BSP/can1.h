#ifndef __CAN1_H_
#define __CAN1_H_
#include "delay.h"

void CAN1_Configure(void);				//can1��ʼ��
void send_mpu_data(float yaw, float gz);
void send_pos_data(float x, float y);
void getPosData(CanRxMsg * msg);
void Can1ReceiveMsgProcess(CanRxMsg *message);
#endif
