#ifndef __ENCODER
#define __ENCODER


typedef struct encoder__
{
    u16 value;
    u16 value_last;
    int cnt;
    int64_t distance;
    int64_t distance_last;
    int deff;
}Enconder;

extern Enconder enconderA;
extern Enconder enconderB;


void posSys_Configure(void);
void getEnconderData(int *a, int *b);

#endif

