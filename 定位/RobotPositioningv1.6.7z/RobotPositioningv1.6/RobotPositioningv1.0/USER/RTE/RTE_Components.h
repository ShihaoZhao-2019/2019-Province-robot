
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Ambition' 
 * Target:  'Template' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define JANSSON

#endif /* RTE_COMPONENTS_H */
