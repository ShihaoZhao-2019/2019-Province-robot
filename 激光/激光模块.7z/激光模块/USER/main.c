#include "stm32f4xx.h"
#include "delay.h"
#include "serial.h"

int main(void)
{
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
		delay_init(168);
		light_uart1_init();
	
		while(1)
		{
			dist = light_data.light_dist.d;
			strength = light_data.light_strength.d;		
		
		}
	

}


