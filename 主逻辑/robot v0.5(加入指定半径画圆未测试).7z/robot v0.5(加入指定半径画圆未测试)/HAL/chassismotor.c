#include "main.h"
#include "math.h"

Chassis_set chassis_set = {0,0,0,0};

void chassis_init(void)
{
		chassis_set.follow_set = position.pos_yaw_angle;
}


void chassis_set_update()
{

	if(rc.sr == 3)
		chassis_set.follow_set += rc.L_x/2500.0f;
	else if(rc.sr == 2)
	{	
		//�Ȱ��ճ����м仭Բ
		circle_task(1150.0f);
	}
	

	out[CHASSIS_FOLLOW] = Calculate_Current_Value(&pid[CHASSIS_FOLLOW], chassis_set.follow_set, position.pos_yaw_angle);
	out[CHASSIS_FOLLOW_SPEED] = Calculate_Current_Value(&pid[CHASSIS_FOLLOW_SPEED], out[CHASSIS_FOLLOW], position.pos_yaw_speed );

	
}

void chassis_out_update()
{
	chassis_set_update();
	
	chassis_set.cm1_real = CM1Encoder.filter_rate;
	chassis_set.cm2_real = CM2Encoder.filter_rate;
	
	out[FR] = pid_incr_calc(&pid_incr[FR], chassis_set.cm1_real, rc.R_y * 1.51f + out[CHASSIS_FOLLOW_SPEED]);
	out[FL] = pid_incr_calc(&pid_incr[FL], chassis_set.cm2_real, rc.R_y * 1.51f - out[CHASSIS_FOLLOW_SPEED]);
	
	Set_ChassisMotor_Current((int16_t)out[FR],(int16_t)out[FL], (int16_t)0, (int16_t)0);	
}



void Set_ChassisMotor_Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq)		//���̵���������ͺ���
{
    CanTxMsg tx_message;
    tx_message.StdId = 0x200;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
    
    tx_message.Data[0] = (uint8_t)(cm1_iq >> 8);
    tx_message.Data[1] = (uint8_t)cm1_iq;
    tx_message.Data[2] = (uint8_t)(cm2_iq >> 8);
    tx_message.Data[3] = (uint8_t)cm2_iq;
    tx_message.Data[4] = (uint8_t)(cm3_iq >> 8);
    tx_message.Data[5] = (uint8_t)cm3_iq;
    tx_message.Data[6] = (uint8_t)(cm4_iq >> 8);
    tx_message.Data[7] = (uint8_t)cm4_iq;
    CAN_Transmit(CAN1,&tx_message);
}
