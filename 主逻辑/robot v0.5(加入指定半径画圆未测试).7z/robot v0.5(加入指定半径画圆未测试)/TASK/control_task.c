#include "main.h"

void control_task() 
{

	chassis_out_update();

}

/******************************************************
**@brief: ָ���뾶��Բ
**				����Բ�Ƕ���������Ƕ�
**@param: radius:�趨�뾶
**
*******************************************************/

void circle_task(float radius)
{
	float x = position.posx;
	float y = position.posy;
	
	float set_r = radius;
	float real_r = sqrt((y-2400)*(y-2400) + (x-0)*(x-0));
	float error_r = set_r - real_r;
	float correct_ratio = 13.0f;
	float correct_angle = error_r/correct_ratio;
	
	float tan_alpha = 0.0f;
	float alpha = 0.0f;
	
	float set_angle = 0.0f;
	
	tan_alpha = (y-2400)/(x-0);	
	alpha = atan(tan_alpha)*(180/PI);
	
	if(x>0&&y<2400){//��һ����
		set_angle = 270 + fabs(alpha);//270~360
		
	}else if(x>0&&y>2400){//�ڶ�����
		set_angle = 270 - fabs(alpha);//180~270
		
	}else if(x<0&&y>2400){//��������
		set_angle = 90 + fabs(alpha);//90~180
		
	}else if(x<0&&y<2400){//��������
		set_angle = 90 - fabs(alpha);//0~90
	
	}
	
	chassis_set.follow_set = set_angle + correct_angle ;
	
}
