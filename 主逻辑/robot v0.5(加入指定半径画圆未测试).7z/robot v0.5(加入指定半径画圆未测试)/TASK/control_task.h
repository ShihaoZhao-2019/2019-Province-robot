#ifndef _CONTROL_TASK_H_
#define _CONTROL_TASK_H_

#define PI 3.14159

void control_task(void);
void circle_task(float radius);



#endif
