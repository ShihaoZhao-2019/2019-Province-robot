#include "main.h"

int IO = 0;

int main(void)
{
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
		delay_init(168);
		Remote_uart2_init();//ң�س�ʼ��
		CAN1_Configure();
		EXTIX_Init();
		BSP_Init();
		uart_init(9600);
		delay_ms(1000);
		TIM6_Configure();
		TIM6_Start();
		fireMotor_fire();
		
	
	while(1)
	{	
		//printf("yaw:%.2f\rX:%.2f\rY:%.2f\r\n", position.pos_yaw_angle,position.posx,position.posy);
		delay_ms(500);
	}
	


}

