#include "main.h"

Ball_set ball_set = {0,0};
int ball_init_flag = 0;
float ball_zero_angle = 0.0f;

void Ball_init(void)
{
	if(FENQIU)
	{
		ball_set.speed_set = -50.0f;
		ball_init_flag = 0;
	}
	else 
	{
		ball_set.speed_set = 0.0f;
		ball_zero_angle = ball_set.set = FEED_Encoder.ecd_angle;
		ball_init_flag = 1;
	}	
}

//��ʼ��ʱ������ת,��������,���ó�ʼλ��,�Ժ����ڳ�ʼλ�û�����ִ�в���ͬ������
void ball_set_update(void)
{
//	if(rc.sr == 1)
//	{

//	}else if(rc.sr == 3)
//	{
//		ball_set.set = ball_zero_angle;
//	}else if(rc.sr == 2)
//	{
//		
//	}
	time_1ms_ball_demo++;
	if(time_1ms_ball_demo<=3000)
	{
		ball_set.set = ball_zero_angle +DIS_ZERO2DISCERN ;
	}
	else if(time_1ms_ball_demo>3000&&time_1ms_ball_demo<=6000)
	{
		ball_set.set = ball_zero_angle;
		
	}else if(time_1ms_ball_demo>6000&&time_1ms_ball_demo<9000)
	{
		ball_set.set = ball_zero_angle + DIS_ZERO2FEED;
	}else if(time_1ms_ball_demo>=9000)
	{
		time_1ms_ball_demo = 0;
	}

}

float angle_set= 0.0f;
float angle_real = 0.0f;
float speed_set = 0.0f;
float speed_real = 0.0f;
void ball_out_update(void)

{

	//�ȴ������ᴥ����
	if(!ball_init_flag)
	{
		out[BALL_SPEED] = Calculate_Current_Value(&pid[BALL_SPEED],ball_set.speed_set, BALL_Encoder.filter_rate);
	}else
	{
	ball_set_update();
	out[BALL] = Calculate_Current_Value(&pid[BALL], ball_set.set, BALL_Encoder.ecd_angle);
	out[BALL_SPEED] = Calculate_Current_Value(&pid[BALL_SPEED], out[BALL], BALL_Encoder.filter_rate);
		
//	angle_set = ball_set.set;
//	angle_real = BALL_Encoder.ecd_angle;
//	speed_set = out[BALL];
//	speed_real = BALL_Encoder.filter_rate;
	}
	
	//��̨ ���� �����������ͺ���
	Set_Cloud_Ball_Feed__Current((int16_t)0,(int16_t)out[BALL_SPEED],0,(int16_t)0);

}


void Set_Cloud_Ball_Feed__Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq)//��̨ ���� ���� ���ͺ���
{
    CanTxMsg tx_message;
    tx_message.StdId = 0x1FF;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
	
	
    tx_message.Data[0] = (uint8_t)(cm1_iq >> 8);
    tx_message.Data[1] = (uint8_t)cm1_iq;
    tx_message.Data[2] = (uint8_t)(cm2_iq >> 8);
    tx_message.Data[3] = (uint8_t)cm2_iq;
    tx_message.Data[4] = (uint8_t)(cm3_iq >> 8);
    tx_message.Data[5] = (uint8_t)cm3_iq;
    tx_message.Data[6] = 0x00;
    tx_message.Data[7] = 0x00;
    CAN_Transmit(CAN1,&tx_message);
}
