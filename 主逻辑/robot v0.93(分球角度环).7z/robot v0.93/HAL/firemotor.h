#ifndef _FIREMOTOR_H_
#define _FIREMOTOR_H_
#include "sys.h"
void fireMotor_stop(void);
void fireMotor_fire(void);
void fireMotor(void);

#endif






