#include "main.h"
#define CLOUD_MIDDLE -68.50f;
Cloud_set cloud_set = {0,0};

void Cloud_init(void)
{
	cloud_set.set = CLOUD_Encoder.ecd_angle;
	cloud_set.back_flag = 0;
	cloud_set.target = CLOUD_MIDDLE;
}


void cloud_set_update(void)
{
	if(!cloud_set.back_flag)
	{
		if((int)cloud_set.set != (int)cloud_set.target)
		{
			cloud_set.set = cloud_set.set < cloud_set.target ? cloud_set.set +0.1f : cloud_set.set - 0.1f;
		}
		else 
			cloud_set.back_flag = 1;
	}
//	else 
//	{
//		cloud_set.set += rc.L_x / 500.0f;
//	}
	cloud_set.real = CLOUD_Encoder.ecd_angle;
//	cloud_set.set += rc.L_x / 500.0f;
}

void cloud_out_update(void)

{
	cloud_set_update();

	out[CLOUD] = Calculate_Current_Value(&pid[CLOUD], cloud_set.set, cloud_set.real);
//	out[CLOUD_SPEED] = Calculate_Current_Value(&pid[CLOUD_SPEED], out[CLOUD], CLOUD_Encoder.filter_rate);
	
	Set_Cloud_Ball_Feed__Current((int16_t)0,(int16_t)0,(int16_t)out[CLOUD],(int16_t)0);
}


