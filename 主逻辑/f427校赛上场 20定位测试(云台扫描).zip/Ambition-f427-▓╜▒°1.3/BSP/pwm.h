#ifndef __PWM_H__
#define __PWM_H__

#include "main.h"


void TIM1_FireMotor_Configure(void);

#endif

