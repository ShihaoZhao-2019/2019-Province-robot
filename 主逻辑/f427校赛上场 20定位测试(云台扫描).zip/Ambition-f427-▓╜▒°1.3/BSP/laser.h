#ifndef LASER_H
#define LASER_H
#include "main.h"

void laser_configuration(void);
void laser_on(void);
void laser_off(void);
#endif
