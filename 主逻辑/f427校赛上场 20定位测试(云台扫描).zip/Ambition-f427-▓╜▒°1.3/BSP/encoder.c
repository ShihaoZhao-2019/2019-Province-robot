#include "main.h"
#include "math.h"


volatile Encoder CM1Encoder            =    {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
volatile Encoder CM2Encoder            =    {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
volatile Encoder CLOUD_Encoder         =    {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
volatile Encoder BALL_Encoder          =    {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
volatile Encoder FEED_Encoder          = 		{0,0,0,0,0,0,0,0,0,0,0,0,0,0};
volatile POSITION position             =    {0,0,0,0};


int walking_count = 0;//����Ȧ��
void Can1ReceiveMsgProcess(CanRxMsg *message)
{
	switch(message->StdId)
	{
		case CAN_ID_CM1:    	getEncoderData(&CM1Encoder, message);   	break;
            
		case CAN_ID_CM2:    	getEncoderData(&CM2Encoder, message); 	  break;
		
		case CAN_ID_MPU:			getMpuData(message);						break;
		
		case CAN_ID_POS:			getPosData(message);						break;
		
		case CAN_ID_CLOUD:		getEncoderData(&CLOUD_Encoder,message);		break;
		
		case CAN_ID_BALL:			getEncoderData(&BALL_Encoder,message);		break;
		
		case CAN_ID_FEED:			getEncoderData(&FEED_Encoder,message);		break;
		
		case CAN_ID_COLOR:		getColorDate(message);

	}
}

/*****************************************************
**@brief �ȴ�can���߻�����ݵõ�mpu�Ͷ�λ����
**			 Ȼ�����0.5s�����Ƕ�û�г���30������Ϊû�б���ײ,Ȼ��Ϳ��������ݼ�¼Ȧ��
**			 ��Ȧ������ʱ,���̽������ģʽ
******************************************************/
void getMpuData(CanRxMsg * msg)
{

	position.last_pos_yaw_angle = position.pos_yaw_angle;
	position.last_pos_yaw_speed = position.pos_yaw_speed;

	for (int i = 0;i < 4;i++)
	{
		(*(uint32_t *)&(position.r_pos_yaw_angle)) = (*(uint32_t *)&(position.r_pos_yaw_angle)) << 8 |  msg->Data[i];
		(*(uint32_t *)&(position.r_pos_yaw_speed))  = (*(uint32_t *)&(position.r_pos_yaw_speed))  << 8 |  msg->Data[4 + i];
	}
	
	if(fabs(position.last_pos_yaw_angle - position.r_pos_yaw_angle) >= 2000.0f)
		position.pos_yaw_angle = position.last_pos_yaw_angle;
	else 
		position.pos_yaw_angle = position.r_pos_yaw_angle;
	if(fabs(position.last_pos_yaw_speed - position.r_pos_yaw_speed) >= 2000.0f)
		position.pos_yaw_speed = position.last_pos_yaw_speed;
	else 
		position.pos_yaw_speed = position.r_pos_yaw_speed;
		
}

void getPosData(CanRxMsg * msg)
{
	position.last_posx = position.posx;
	position.last_posy = position.posy;
	for (int i = 0;i < 4;i++)
	{
		(*(uint32_t *)&position.r_posx) = (*(uint32_t *)&position.r_posx) << 8 |  msg->Data[i];
		(*(uint32_t *)&position.r_posy) = (*(uint32_t *)&position.r_posy) << 8 |  msg->Data[4 + i];
	}	
	if(fabs(position.last_posx - position.r_posx) >= 300.0f)
		position.posx = position.last_posx;
	else 
		position.posx = position.r_posx;
	if(fabs(position.last_posy - position.r_posy) >= 300.0f)
		position.posy = position.last_posy;
	else 
		position.posy = position.r_posy;
	
	
}


void getEncoderData(volatile Encoder *v, CanRxMsg * msg)
{

	int i=0;
	int32_t temp_sum = 0;    
	v->last_raw_value = v->raw_value;
	v->raw_value = (msg->Data[0]<<8)|msg->Data[1];
	v->diff = v->raw_value - v->last_raw_value;
	if(v->diff < -4096)    //���α������ķ���ֵ���̫�󣬱�ʾȦ�������˸ı�
	{
		v->round_cnt++;
		v->ecd_raw_rate = v->diff + 8192;
	}
	else if(v->diff>4096)
	{
		v->round_cnt--;
		v->ecd_raw_rate = v->diff - 8192;
	}		
	else
	{
		v->ecd_raw_rate = v->diff;
	}
	//����õ������ı��������ֵ
	v->ecd_value = v->raw_value + v->round_cnt * 8192;
	//����õ��Ƕ�ֵ����Χ���������
	v->ecd_angle = (float)(v->raw_value - v->ecd_bias)*360/8192 + v->round_cnt * 360;
	v->rate_buf[v->buf_count++] = v->ecd_raw_rate;
	if(v->buf_count == RATE_BUF_SIZE)
	{
		v->buf_count = 0;
	}
	//�����ٶ�ƽ��ֵ
	for(i = 0;i < RATE_BUF_SIZE; i++)
	{
		temp_sum += v->rate_buf[i];
	}
	v->filter_rate = (int32_t)(temp_sum/RATE_BUF_SIZE);
	if(!v->flag)
		v->init_angle=v->ecd_angle;
	v->flag=1;
	
}

void getColorDate(CanRxMsg * msg)
{
	ball_color = msg->Data[0];
}
