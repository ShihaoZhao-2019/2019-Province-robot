#ifndef __MAIN
#define __MAIN

#include "stm32f4xx.h"
#include "usart.h"
#include "sys.h"
#include "bsp.h"
#include "can1.h"
#include "can2.h"
#include "timer.h"
#include "rm_pid.h"
#include "encoder.h"
#include "chassismotor.h"
#include "math.h"
#include "control_task.h"
#include "remote.h"
#include "string.h"
#include "ballmotor.h"
#include "cloudmotor.h"
#include "feedmotor.h"
#include "exit.h"
#include "pwm.h"
//#include "2_4g.h"
//#include "spi.h"
//#include "exit.h"
#include "firemotor.h"
#include "led.h"
#include "serial.h"

//#define MODE_SWITCH GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_0);//�� 1 �� 0
//#define START_SWITCH GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_1);

#endif


