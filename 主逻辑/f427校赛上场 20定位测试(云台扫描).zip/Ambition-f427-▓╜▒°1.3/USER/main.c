#include "main.h"
	u8 bsp_flag = 0;
	u8 offset_flag = 0;
	
void start_and_mode_switch_init(void);
	
int main(void)
{
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
		delay_init(180);
		Remote_uart1_init();//ң�س�ʼ��
		start_and_mode_switch_init();
		BSP_Init(1);	
		led_configuration();

		flow_led_on(3);
		flow_led_on(4);
		flow_led_on(5);
		flow_led_on(6);
		flow_led_on(7);
	while(1)
	{

//			fireMotor();//Ħ���ֿ���
	}
}

//void start_and_mode_switch_init()
//{
//	GPIO_InitTypeDef  GPIO_InitStructure;
//  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);//ʹ��GPIOA,GPIOEʱ�� 
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1; //KEY0 KEY1 KEY2��Ӧ����
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//��ͨ����ģʽ
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
//  GPIO_Init(GPIOF, &GPIO_InitStructure);//��ʼ��GPIOC6
//}

