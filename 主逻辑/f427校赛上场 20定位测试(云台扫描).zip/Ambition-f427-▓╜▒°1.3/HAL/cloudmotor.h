#ifndef __CLOUD
#define __CLOUD

#include "sys.h"

void cloud_set_update(void);
void cloud_out_update(void);

#define CLOUD_MIDDLE -56.00f

typedef struct Cloud_set
{
	float set;
	float real;
	float speed_set;
	float speed_real;
	float back_flag;
	float target;
}Cloud_set;

extern Cloud_set cloud_set;
extern int robot_cloud_mode;

enum{
	robot_fix,//�̶�
	robot_scan//ɨ��
	
};

void Cloud_init(void);
                               






#endif


