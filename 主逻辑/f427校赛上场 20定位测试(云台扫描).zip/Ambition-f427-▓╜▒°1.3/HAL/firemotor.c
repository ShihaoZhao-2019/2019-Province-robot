#include "main.h"

uint64_t fireFlag = 0;
int16_t last_shift = 0;
int16_t now_shift = 0;

void fireMotor_stop()
{
	TIM1->CCR1 = 1000;
	TIM1->CCR4 = 1000;
}


void fireMotor_fire()
{

	TIM1->CCR1 = 1310;
	TIM1->CCR4 = 1310;
}

void fireMotor()
{
	fireMotor_fire();
}
