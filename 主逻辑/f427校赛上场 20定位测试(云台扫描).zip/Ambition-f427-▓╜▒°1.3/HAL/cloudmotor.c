#include "main.h"

Cloud_set cloud_set = {0,0};
float SET_CENTER = 0.0f;//��̨��λ��
int robot_cloud_mode = robot_scan;
void Cloud_init(void)
{
	cloud_set.set = CLOUD_Encoder.ecd_angle;
	cloud_set.back_flag = 0;
	cloud_set.target = CLOUD_MIDDLE;
}


void cloud_set_update(void)
{
	if(!cloud_set.back_flag)
	{
		if((int)cloud_set.set != (int)cloud_set.target)
		{
			cloud_set.set = cloud_set.set < cloud_set.target ? cloud_set.set +0.6f : cloud_set.set - 0.6f;
		}
		else 
			cloud_set.back_flag = 1;
			SET_CENTER = cloud_set.set;
	}
	else if(rc.sl == 2)
	{
		static u8 scan_flag = 0;
		static u8 arrive_left_flag = 0;
		static u8 scan_finish_flag = 0;
		
		if(robot_cloud_mode == robot_fix ) cloud_set.set = SET_CENTER;//Ĭ��ͣ���м�λ��
		else if(robot_cloud_mode == robot_scan) scan_flag = 1;
		
		if(scan_flag == 1)
		{
			if((cloud_set.real <= SET_CENTER -150 +10)&&(cloud_set.real >= SET_CENTER -150-10)) arrive_left_flag = 1;//�ж��Ƿ񵽴��������
			if(arrive_left_flag == 0)
			{
				cloud_set.set -= 0.15f;
			}else
			{
				if((cloud_set.real <= SET_CENTER + 150 + 10)&&(cloud_set.real >= SET_CENTER + 150 - 10)) scan_finish_flag = 1;
				if(scan_finish_flag == 0) 
				{
					cloud_set.set += 0.075f;
				}
				else
				{
					cloud_set.set = SET_CENTER;
				}
				
			}
	
		}

	}else

	{
		cloud_set.set += rc.L_x / 500.0f;
	}
	
	
	//��ʵֵ����
	cloud_set.real = CLOUD_Encoder.ecd_angle;
	cloud_set.speed_real = CLOUD_Encoder.filter_rate;

}

void cloud_out_update(void)
{
	
	{
		cloud_set_update();
		out[CLOUD] = Calculate_Current_Value(&pid[CLOUD], cloud_set.set, cloud_set.real);
		out[CLOUD_SPEED] = Calculate_Current_Value(&pid[CLOUD_SPEED], out[CLOUD], cloud_set.speed_real);
		Set_Cloud_Ball_Feed__Current((int16_t)0,(int16_t)0,(int16_t)out[CLOUD_SPEED],(int16_t)0);		
	}

}


