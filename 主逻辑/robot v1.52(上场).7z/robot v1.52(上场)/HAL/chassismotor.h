#ifndef _CHASSISMOTOR_H_
#define _CHASSISMOTOR_H_

#include "delay.h"

#define BASE_SPEED -800

void chassis_set_update(void);
void chassis_out_update(void);

enum{
	robot_walk = 0,	
	robot_shoot
};

typedef struct Chassis_set
{
	
	u8 robot_mode;
	float cm1_set;
	float cm2_set;
	
	float cm1_real;
	float cm2_real;
	
	float follow_set;
	float follow_real;
	
	float follow_speed_set;
	float follow_speed_real;
	u8 quadrant;
	uint16_t mode_cnts;
}Chassis_set;

extern Chassis_set chassis_set;
extern int robot_chassis_mode;//�����˵���״̬ 0���� 1 ���
extern u8 stop_flag;
void chassis_init(void);
void Set_ChassisMotor_Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq);
extern u8 chassisWwork;
extern uint8_t scan_cnts;
u8 check_crash_when_running(void);
void Gogogo(void);
extern float max_speedx, max_speedy;
extern float diff_x, diff_y;
extern int cntsx, cntsy;
void change_r_speed(void);
#endif
