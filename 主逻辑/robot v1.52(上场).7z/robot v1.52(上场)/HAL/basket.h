#ifndef BASKET_H_
#define BASKET_H_

#include "stm32f4xx.h"


#define BASKET_4 GPIO_ReadInputDataBit(GPIOI,GPIO_Pin_0)			//4
#define BASKET_3 GPIO_ReadInputDataBit(GPIOH,GPIO_Pin_11)		//3
#define CAMP GPIO_ReadInputDataBit(GPIOH,GPIO_Pin_10)    //camp  0 bule
#define BASKET_1 GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_15)    //1
#define BASKET_2 GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_14)    //2
#define _start GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_13)    //

void cala_second_basket(void);
void keyboardInit(void);
extern float cala_aimed_angle;

u8 check_quadrant(void);			//������� �����ж�ͣ��ʱ��λ��
u8 get_camp_info(void);
typedef struct
{
	float stop_angle1;
	float stop_angle2;
	float height1;
	float height2;
  float set_chassis_angle1;
	float set_chassis_angle2;
	u8 quadrant1;
	u8 quadrant2;
	u8 basket_info_flag;
}Basket_Info;

extern Basket_Info basket_info;
#endif
