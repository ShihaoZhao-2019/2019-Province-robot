#ifndef _EXIT
#define _EXIT

#include "sys.h"
void EXTIX_Init(void);
#define DAODAN_FINISH GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_1)
#define DAODAN GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)
#define FENQIU GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)


extern u8 feed_mode_ready;
extern u8 feed_mode_finish_ready;
void final_exit(void);
#endif

