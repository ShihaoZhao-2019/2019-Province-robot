#include "main.h"

Cloud_set cloud_set = {0,0};
DIS_ANGLE dis_buffer = {0};//����buffer
 
float SET_CENTER = 0.0f;//��̨��λ��
float beat_angle = 0.0f;//�����λ��
int max_distance = 0;//��Զ����
int robot_cloud_mode = robot_scan;
uint64_t scan_over_cnts = 0;

void Cloud_init(void)
{
	cloud_set.set = CLOUD_Encoder.ecd_angle;
	cloud_set.back_flag = 0;
	cloud_set.target = CLOUD_MIDDLE;
	dis_buffer.scan_flag = 0;
}

u8 scan_finish_flag = 0;
float target_height;
void cloud_set_update(void)
{
	
//	if(dis_buffer.aimed_flag)
//	{
//		scan_finish_flag = 1;
//	}
	if(!cloud_set.back_flag)
	{
		if((int)cloud_set.set != (int)cloud_set.target)
		{
			cloud_set.set = cloud_set.set < cloud_set.target ? cloud_set.set +0.05f : cloud_set.set - 0.05f;
		}
		else 
			cloud_set.back_flag = 1;
			SET_CENTER = cloud_set.set;
	}
	else 
	{

	if(1)						//ȫ�Զ�ɨ��ģʽ 30�ż���
	{
		 solve_white_black_angle();
		 if(dis_buffer.scan_flag == 0)
		 { 
			 ms1 = 0 ;
			 scan_over_cnts = 0;
		 }
		 if(dis_buffer.scan_flag == 1)							//�ռ�״̬ ��̨����ȴ�ɨ���ź�
		 {		
			
			 scan_over_cnts = 0;
			 if(ReadyToScan())
			 {	
				 if(!ssinfo.info_flag)
				 {
					 ssinfo.yaw_angle = position.pos_yaw_angle;
					 ssinfo.posx = dis_buffer.dis_x;
					 ssinfo.posy = dis_buffer.dis_y;	
					 ssinfo.info_flag = 1;						 
				 }	
				 dis_buffer.scan_flag = 2;

			 }
		 }
		 else if(dis_buffer.scan_flag == 2)					// ��ʼɨ�� 
		 {
				if(! ssinfo.info_flag)
				{
					ssinfo.yaw_angle = position.pos_yaw_angle;
					ssinfo.posx = dis_buffer.dis_x;
					ssinfo.posy = dis_buffer.dis_y;	
					ssinfo.info_flag = 1;						 
				}	
			 static uint16_t cnts = 0;
			 float tana;
			 scan_over_cnts = 0;
//			 cloud_set.set -= 0.05f;
			 tana = (atan((float)dis_buffer.longitudinal_separation / (float)dis_buffer.cross_range)) * (180.0f / PI);
			 dis_buffer.max_dis = sqrt(dis_buffer.longitudinal_separation * dis_buffer.longitudinal_separation + dis_buffer.cross_range * dis_buffer.cross_range);
			 cloud_set.pink_set = cloud_set.set = READY_TO_SCAN_ANGLE - tana * 3.3333333f;
			 if(fabs(cloud_set.set - CLOUD_Encoder.ecd_angle) < 10.0f && fabs(chassis_set.follow_set - chassis_set.follow_real) <= 10.0f)
			 {
				 cnts++;
				 if(cnts >= 1000)
				 {
					 if(fabs(dis_buffer.max_dis - aser_ranging) > 20.0f)
					 {
						 scan_over_cnts = 0;
						 ClearAllScanFlags();
						 chassis_set.robot_mode = 1;
						 dis_buffer.scan_flag = 0;
						 cnts = 0;
					 }
					 else 
					 {
							dis_buffer.aimed_flag = 1;
							dis_buffer.scan_flag = 3;
						  cnts = 0;
					 }
				 }
			 }
			 else
			 {
				 cnts = 0;
			 }

			 
		 }
		 else if(dis_buffer.scan_flag == 3)					//ɨ����� �ҵ���Զ�� ���Կ�ʼ���
		 {
			 scan_over_cnts++;
			 if(scan_over_cnts <= 500)
			 {
				 calibration_pos();
				 send_pos_data(dis_buffer.dis_x, dis_buffer.dis_y, 1);
				 if(ssinfo.info_flag <= 1)
				 {
					 ssinfo.yaw_angle = position.pos_yaw_angle;
					 ssinfo.posx = dis_buffer.dis_x;
					 ssinfo.posy = dis_buffer.dis_y;	
					 ssinfo.info_flag = 2;						 
				 }				 
			 }
			 else if(scan_over_cnts > 500 && scan_over_cnts <= 1000)
				 send_pos_data(dis_buffer.dis_x, dis_buffer.dis_y, 0);
			 else 
			 {
				 if(CAMP == red)
				 {
					if(Outsert_Q(CHECK_Q)==pink)
					{	
						if(check_quadrant() == basket_info.quadrant1)
						{
							target_height = basket_info.height1;
							set_func_coef(basket_info.height1);
						}
						else if(check_quadrant() == basket_info.quadrant2)
						{
							target_height = basket_info.height2;
							set_func_coef(basket_info.height2);
						} 
						cloud_set.set = cloud_set.pink_set - cloud_set.center_offset * 3.333333333f;
						fireMotor_fire(cloud_set.white_black_aim_dis);  ///28.28						
						Gantaniangde();
					}
					else if(Outsert_Q(CHECK_Q)==white)
					{
						solve_center_angle();
						cloud_set.set = cloud_set.white_black_set;
						Gantaniangde();
					}
					else if(Outsert_Q(CHECK_Q)==no_ball)//û������
					{
							Gogogo();
					}
				}
				else if(CAMP == blue)
				{
					if(Outsert_Q(CHECK_Q)==pink)
					{	
						if(check_quadrant() == basket_info.quadrant1)
						{
							target_height = basket_info.height1;
							set_func_coef(basket_info.height1);
						}
						else if(check_quadrant() == basket_info.quadrant2)
						{
							target_height = basket_info.height2;
							set_func_coef(basket_info.height2);
						} 
						cloud_set.set = cloud_set.pink_set - cloud_set.center_offset * 3.333333333f;
						fireMotor_fire(cloud_set.white_black_aim_dis);  ///28.28						
						Gantaniangde();
					}
					else if(Outsert_Q(CHECK_Q)==black)
					{
						solve_center_angle();
						cloud_set.set = cloud_set.white_black_set;
						Gantaniangde();
					}
					else if(Outsert_Q(CHECK_Q)==no_ball)//û������
					{
							Gogogo();
					}
				}					
//				 if(rc.R_y >= 500)
//				 {
//					 		ClearAllScanFlags();
//							chassis_set.robot_mode = 1;
//							dis_buffer.scan_flag = 0;
//				 }

			 }
				 
		 }
		 else if(dis_buffer.scan_flag == 4)					//ɨ����� δ�ҵ���Զ�� �ȴ���һָ��
		 {

//			 scan_over_cnts = 0;
//			 ClearAllScanFlags();
//			 chassis_set.robot_mode = 1;
//			 dis_buffer.scan_flag = 0;
		 }
		 
		 if(dis_buffer.scan_flag == 2 || dis_buffer.scan_flag == 3 || dis_buffer.scan_flag == 1)
		 {
			 if(check_crash_when_scaning_and_shooting())
			 {
				 ClearAllScanFlags();
				 chassis_set.robot_mode = 1;
				 dis_buffer.scan_flag = 0;          //ɨ�������������м�⵽ײ�� ��ʼ����ɨ��
			 }
		 }
	}
}
	
	//��ʵֵ����
	cloud_set.real = CLOUD_Encoder.ecd_angle;
	cloud_set.speed_real = CLOUD_Encoder.filter_rate;
	
}

void cloud_out_update(void)
{
	{
		cloud_set_update();
		out[CLOUD] = Calculate_Current_Value(&pid[CLOUD], cloud_set.set, cloud_set.real);
		cloud_set.speed_set = out[CLOUD];
		out[CLOUD_SPEED] = Calculate_Current_Value(&pid[CLOUD_SPEED], cloud_set.speed_set, cloud_set.speed_real);
//		if(chassis_set.robot_mode == 3)
//			out[CLOUD_SPEED] = 0;
		Set_CloudCurrent((int16_t)out[BALL_SPEED], (int16_t)out[CLOUD_SPEED]);		
	}

}
u16 ready_to_scan_cnts; 
u8 ReadyToScan(void)
{
//	chassis_set.follow_set = 180.0f;
//	cloud_set.set = READY_TO_SCAN_ANGLE;
	if(fabs(cloud_set.set - CLOUD_Encoder.ecd_angle) < 10.0f && fabs(chassis_set.follow_set - chassis_set.follow_real) <= 10.0f)
//		if(fabs(cloud_set.set - CLOUD_Encoder.ecd_angle) < 1.0f )
	{
		ready_to_scan_cnts++;
		if(fabs(aser_ranging2 - aser_ranging) >= 30.0f && ready_to_scan_cnts >= 500)
		{
			dis_buffer.longitudinal_separation = aser_ranging3;
			dis_buffer.cross_range = aser_ranging2 + 20;
			ready_to_scan_cnts = 0;
			flow_led_on(7);
			return 1;
		}
		flow_led_off(7);
		return 0;
	}
	flow_led_off(7);
	ready_to_scan_cnts = 0;
	return 0;
}
void FindTheFurthest(void)
{	
	if(dis_buffer.aimed_angle >= 90.0f)    //�����ɨ��Ƕȹ��� �ж�Ϊ�Ѿ��Ѱ�
	{
		dis_buffer.scan_flag = 4;
	}
	dis_buffer.aimed_angle = fabs(CLOUD_Encoder.ecd_angle - READY_TO_SCAN_ANGLE) / 3.33333333333333333;
	dis_buffer.cosa = cos((double)dis_buffer.aimed_angle * 0.01745329251994329576923690768489);
	dis_buffer.aimed_dis = (double)dis_buffer.cross_range /  dis_buffer.cosa;
	
	if(fabs(dis_buffer.aimed_dis - aser_ranging) <= 15.0f)
	{
		dis_buffer.on_target_counts ++;
		if(dis_buffer.on_target_counts >= 15)
		{
			dis_buffer.on_target_flag = 1;
			dis_buffer.on_target_dis = aser_ranging;
		}
	}
	else 
	dis_buffer.on_target_counts = 0;
	dis_buffer.last_distance =  dis_buffer.new_distance;
	dis_buffer.new_distance = aser_ranging;								
	dis_buffer.diff_dis = (int16_t)(dis_buffer.new_distance - dis_buffer.on_target_dis);
	if(dis_buffer.on_target_flag)
	{
		if(dis_buffer.diff_dis >= dis_buffer.max_diff)
		{
			dis_buffer.max_diff = dis_buffer.diff_dis;
			dis_buffer.max_dis_to_angle = CLOUD_Encoder.ecd_angle;
		}
		else 
		{
			dis_buffer.max_dis = dis_buffer.max_diff + dis_buffer.on_target_dis;
//			dis_buffer.longitudinal_separation = dis_buffer.cross_range * tan(dis_buffer.aimed_angle * 0.01745329251994329576923690768489f);
			dis_buffer.longitudinal_separation = sqrt(dis_buffer.max_dis * dis_buffer.max_dis - dis_buffer.cross_range * dis_buffer.cross_range);
			dis_buffer.aimed_flag = 1;
			dis_buffer.scan_flag = 3;
			cloud_set.set = dis_buffer.max_dis_to_angle;			
		}

	}

}
void ClearAllScanFlags(void)
{
	dis_buffer.aimed_angle = 0.0f;
	dis_buffer.cosa = 0.0;
	dis_buffer.aimed_dis = 0.0;
	dis_buffer.on_target_counts = 0;
	dis_buffer.on_target_flag = 0;
	dis_buffer.on_target_dis = 0;
	dis_buffer.new_distance = 0;
	dis_buffer.diff_dis = 0;
	dis_buffer.max_diff = 0;
	dis_buffer.max_dis_to_angle = 0;
	dis_buffer.max_dis = 0;
	dis_buffer.longitudinal_separation = 0;
	dis_buffer.aimed_flag = 0;
	dis_buffer.cross_range = 0;
	dis_buffer.dis_x = 0;
	dis_buffer.dis_y = 0;
	ssinfo.info_flag = 0;
}
void calibration_pos(void)
{
	if(chassis_set.quadrant == 1)
	{
		dis_buffer.dis_y = (dis_buffer.cross_range - 5)* 10;						//�˴���Ҫ�����ⵥλת����mm
		dis_buffer.dis_x = 2400 - (dis_buffer.longitudinal_separation ) * 10; 
	}
	else if(chassis_set.quadrant == 2)
	{
		dis_buffer.dis_x = 2400 - (dis_buffer.cross_range - 5)* 10;	
		dis_buffer.dis_y = 4800 - (dis_buffer.longitudinal_separation) * 10;		
	}
	else if(chassis_set.quadrant == 3)
	{
		dis_buffer.dis_y = 4800 - (dis_buffer.cross_range - 5)* 10;	
		dis_buffer.dis_x = -2400 + (dis_buffer.longitudinal_separation ) * 10;		
	}
	else if(chassis_set.quadrant == 4)
	{
		dis_buffer.dis_x = -2400 + (dis_buffer.cross_range - 5)* 10;	
		dis_buffer.dis_y = (dis_buffer.longitudinal_separation) * 10;		
	}
}


//�����м���λ��
void solve_center_angle()
{
	float dui;
	float lin;
	float tan_theat;
	float posx = position.posx / 10.0f;
	float posy = position.posy / 10.0f;
	if(chassis_set.quadrant == 1)
	{
		lin = posx - 11;
		dui = 240 - (posy + 8);
	}
	else if(chassis_set.quadrant == 2)
	{
		lin = (posy - 8) - 240;
		dui = posx - 11;
	}
	else if(chassis_set.quadrant == 3)
	{
		lin = - (posx + 11);
		dui = (posy - 8) - 240;		
	}
	else if(chassis_set.quadrant == 4)
	{
		lin = 240 - (posy + 8);
		dui = - (posx + 11);			
	}
	tan_theat = dui / lin;
	float theat = atan(tan_theat)*(180/PI);
	cloud_set.white_black_set = theat*3.3333333f + SET_CENTER;
	set_func_coef(40);
	fireMotor_fire(sqrt(dui*dui+lin*lin));
}

void solve_white_black_angle(void)
{
	float a1, tan1;
	float a2, tan2;
	float lin1, lin2, dui1, dui2;
	float posx = position.posx / 10.0f;
	float posy = position.posy / 10.0f;
	if(chassis_set.quadrant == 1)
	{
		lin1 = (posy + 8) - 20.0f;
		dui1 = 220.0f - (posx - 11);
		lin2 = (posy + 8);
		dui2 = 240.0f - (posx - 11);
	}
	else if(chassis_set.quadrant == 2)
	{
		lin1 = 220.0f - (posx - 8);
		dui1 = 460.0f - (posy - 11);
		lin2 = 240.0f - (posx - 8);
		dui2 = 480.0f - (posy - 11);
	}
	else if(chassis_set.quadrant == 3)
	{
		lin1 = 460.0f - (posy - 8);
		dui1 = 220.0f + (posx + 11);
		lin2 = 480.0f - (posy - 8);
		dui2 = 240.0f + (posx + 11);
	}
	else if(chassis_set.quadrant == 4)
	{
		lin1 = 220.0f + (posx + 8);
		dui1 = (posy + 11) - 20.0f;
		lin2 = 240.0f + (posx + 8 );
		dui2 = (posy + 11);
	}	
	tan1 = dui1 / lin1;
	tan2 = dui2 / lin2;
	a1 = atan(tan1)*(180/PI);
	a2 = atan(tan2)*(180/PI);
	if(fabs(a1 - a2) < 45.0f)
		cloud_set.center_offset = a1 - a2;
	else 
		cloud_set.center_offset = 0.0f;	
	if(ssinfo.info_flag == 2)
	{
		cloud_set.white_black_aim_dis = sqrt(( dui1)* (dui1) + (lin1)* (lin1));
		
	}
	else if(ssinfo.info_flag < 2)
	{
		cloud_set.white_black_aim_dis = dis_buffer.max_dis - 25.284f;
	}
	

}
void aimed_the_center_point(void)
{
	
}
void Set_CloudCurrent(int16_t cm2_iq, int16_t cm3_iq)//��̨ ���� ���� ���ͺ���
{
    CanTxMsg tx_message;
    tx_message.StdId = 0x1FF;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
	
    tx_message.Data[0] = 0x00;
    tx_message.Data[1] = 0x00;
    tx_message.Data[2] = (uint8_t)(cm2_iq >> 8);
    tx_message.Data[3] = (uint8_t)cm2_iq;
    tx_message.Data[4] = (uint8_t)(cm3_iq >> 8);
    tx_message.Data[5] = (uint8_t)cm3_iq;
    tx_message.Data[6] = 0x00;
    tx_message.Data[7] = 0x00;
    CAN_Transmit(CAN2,&tx_message);
}
