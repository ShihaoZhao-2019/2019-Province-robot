#include "main.h"
#include "math.h"

Chassis_set chassis_set = {0,0,0,0};
int robot_chassis_mode = robot_walk;
int base_speed = 1500;//���̻����ٶ�
u8 stop_flag = 0;
u8 retreat_flag = 0;
u8 uuu = 0;
uint8_t scan_cnts = 0;
uint8_t scan_cnts1 = 0;
static float max_speedx, max_speedy;
static float diff_x, diff_y;
static int cntsx, cntsy;
void chassis_init(void)
{
	chassis_set.follow_set = position.pos_yaw_angle;
	chassis_set.robot_mode = 1;
	chassis_set.mode_cnts = 0;
}

void chassis_set_update()
{

	
	//�����Ȧԭ��תȦ������
	if(chassis_set.follow_set-position.pos_yaw_angle>180)
	{
		walking_count --;
	}else if(chassis_set.follow_set-position.pos_yaw_angle<-180)
	{
		walking_count++;
	}
	chassis_set.quadrant = check_quadrant();
	//����һȦ����

	if(rc.sr == 2)//ң��ģʽ
	{
		uuu = 1;
		base_speed = rc.R_y * 1.51f;
		chassis_set.follow_set -= rc.L_x/1500.0f;
	}

	if(rc.sr == 3)
	{
		if(chassis_set.robot_mode == 1)					//�ƶ�
		{
//			if(check_crash_when_running())
//			{
//				base_speed = 0;
//				chassis_set.robot_mode = 3;
//			}
//			if(!scan_cnts)
			base_speed = -800;
//			else 
//				base_speed = rc.R_y * 1.51f;
			circle_task(1400.0f);	
//			if((chassis_set.follow_real - scan_cnts * 360) >= 50.0f && dis_buffer.scan_flag == 5)
//			{
//				chassis_set.robot_mode = 3;
//			}
			if((chassis_set.follow_real - scan_cnts * 360) >= basket_info.stop_angle1 && chassis_set.quadrant == basket_info.quadrant1)
			{	
				
			if(Outsert_Q(CHECK_Q)!=no_ball) stop_flag = 1;
			else stop_flag = 0;

			if(stop_flag==1)
			{
				chassis_set.follow_set = basket_info.set_chassis_angle1 + scan_cnts * 360;
				cloud_set.set = READY_TO_SCAN_ANGLE;	
				chassis_set.robot_mode = 2;					
			}
				scan_cnts++;
			}
			else if((chassis_set.follow_real - scan_cnts1 * 360) >= basket_info.stop_angle2 && chassis_set.quadrant == basket_info.quadrant2)
			{	
	
			 
			if(Outsert_Q(CHECK_Q)!=no_ball) stop_flag = 1;
			else stop_flag = 0;

			if(stop_flag==1)
			{
				chassis_set.follow_set = basket_info.set_chassis_angle2 + scan_cnts1 * 360;
				cloud_set.set = READY_TO_SCAN_ANGLE;	
				chassis_set.robot_mode = 2;					
			}

				scan_cnts1++;
			}
		}
		else if(chassis_set.robot_mode == 2 && dis_buffer.scan_flag == 0)			//��ʼɨ�� ������׼ ����У׼
		{
			cntsx = 0;
			cntsy = 0;
			base_speed = 0;
			dis_buffer.scan_flag = 1;
		}
		else if(chassis_set.robot_mode == 3)
		{
			base_speed = 500;
			chassis_set.mode_cnts ++;
			if(chassis_set.mode_cnts >= 3000)
			{
				base_speed = -800;
				dis_buffer.scan_flag = 0;
				chassis_set.mode_cnts = 0;
				chassis_set.robot_mode = 1;
			}
		}
	}

//	if( retreat_flag == 1) chassis_set.follow_set = chassis_set.follow_real;
	
	
	
	

	chassis_set.follow_real = position.pos_yaw_angle;
	out[CHASSIS_FOLLOW] = Calculate_Current_Value(&pid[CHASSIS_FOLLOW], chassis_set.follow_set, chassis_set.follow_real );
	chassis_set.follow_speed_set = out[CHASSIS_FOLLOW];
	chassis_set.follow_speed_real = position.pos_yaw_speed / 10.0f;
	out[CHASSIS_FOLLOW_SPEED] = Calculate_Current_Value(&pid[CHASSIS_FOLLOW_SPEED], chassis_set.follow_speed_set, chassis_set.follow_speed_real );

	
}

u8 start_flag = 0;

void chassis_out_update()
{
//	if(START_SWITCH) start_flag = 1;
//	if(position.posx != 6.0f && position.posy != 6.0f && position.pos_yaw_angle != 6.0f && position.last_pos_yaw_speed != 6.0f)
	{
		chassis_set_update();
		
		chassis_set.cm1_real = CM1Encoder.filter_rate;
		chassis_set.cm2_real = CM2Encoder.filter_rate;
//		
		out[FR] = pid_incr_calc(&pid_incr[FR], chassis_set.cm1_real, base_speed + out[CHASSIS_FOLLOW_SPEED]);
		out[FL] = pid_incr_calc(&pid_incr[FL], chassis_set.cm2_real, -base_speed + out[CHASSIS_FOLLOW_SPEED]);
//		out[FR] = pid_incr_calc(&pid_incr[FR], chassis_set.cm1_real, base_speed );
//		out[FL] = pid_incr_calc(&pid_incr[FL], chassis_set.cm2_real, -base_speed );
//		out[FR] = pid_incr_calc(&pid_incr[FR], chassis_set.cm1_real, base_speed - rc.L_x * 1.51f);
//		out[FL] = pid_incr_calc(&pid_incr[FL], chassis_set.cm2_real, -base_speed - rc.L_x * 1.51f);
		Set_ChassisMotor_Current((int16_t)out[FR],(int16_t)out[FL], (int16_t)0, (int16_t)0);	
	}
}

//float last_pos_x, last_pos_y;
//	static float max_speedx, max_speedy;
//	static float diff_x, diff_y;
u8 check_crash_when_running(void)
{
//	static float max_speedx, max_speedy;
//	static float diff_x, diff_y;
//	static int cntsx, cntsy;
	diff_x = fabs(position.posx - position.last_posx);
	diff_y = fabs(position.posy - position.last_posy);
	position.last_posx = position.posx;
	position.last_posy = position.posy;
	max_speedx = max_speedx < diff_x ? diff_x : max_speedx;
	max_speedy = max_speedy < diff_y ? diff_y : max_speedy;
	if((diff_x <= (max_speedx / 5.0f)) && max_speedx != 0.0f)
	{
		cntsx++;
		if(cntsx >= 4000)
		{
			cntsx = 0;
			return 1;
		}
		else 
			return 0;
	}
	if(diff_y <= (max_speedy / 5.0f) && max_speedy != 0.0f)
	{
		cntsy++;
		if(cntsy >= 4000)
		{
			cntsy = 0;
			return 1;
		}
		else 
			return 0;
	}	
	cntsx = 0;
	cntsy = 0;
	return 0;
}

//������ֱ�־λ,���������ģʽת��������ģʽ
void Gogogo()
{
			robot_feed_mode = robot_await;
			ClearAllScanFlags();
			chassis_set.robot_mode = 1;
			dis_buffer.scan_flag = 0;	
			robot_feed_mode = robot_await;
}

void Set_ChassisMotor_Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq)		//���̵���������ͺ���
{
    CanTxMsg tx_message;
    tx_message.StdId = 0x200;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
    
    tx_message.Data[0] = (uint8_t)(cm1_iq >> 8);
    tx_message.Data[1] = (uint8_t)cm1_iq;
    tx_message.Data[2] = (uint8_t)(cm2_iq >> 8);
    tx_message.Data[3] = (uint8_t)cm2_iq;
    tx_message.Data[4] = (uint8_t)(cm3_iq >> 8);
    tx_message.Data[5] = (uint8_t)cm3_iq;
    tx_message.Data[6] = (uint8_t)(cm4_iq >> 8);
    tx_message.Data[7] = (uint8_t)cm4_iq;
    CAN_Transmit(CAN1,&tx_message);
}
