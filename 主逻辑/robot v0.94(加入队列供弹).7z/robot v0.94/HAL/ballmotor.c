#include "main.h"

char ball_buffer[3] = {no_ball, no_ball, no_ball};
Ball_set ball_set = {0,0};

int ball_init_flag = 0;
float ball_zero_angle = 0.0f;

u8 ball_color = 0x00;

void Ball_init(void)
{
	
	GPIO_InitTypeDef  GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);//ʹ��GPIOA,GPIOEʱ�� 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8; //KEY0 KEY1 KEY2��Ӧ����
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//��ͨ����ģʽ
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  GPIO_Init(GPIOC, &GPIO_InitStructure);//��ʼ��GPIOC6
	
	if(FENQIU)
	{
		ball_set.speed_set = -150.0f;
		ball_init_flag = 0;
	}
	else 
	{
		ball_set.speed_set = 0.0f;
		ball_zero_angle = ball_set.set = FEED_Encoder.ecd_angle;
		ball_init_flag = 1;
	}	
}

u8 move_flag = 0;//�����ƶ���־λ
u8 real_ball_color = 0;//���ڷֵ������ɫ
uint64_t ball_times = 0;
uint64_t has_ball_times = 0;
//��ʼ��ʱ������ת,��������,���ó�ʼλ��,�Ժ����ڳ�ʼλ�û�����ִ�в���ͬ������
void ball_set_update(void)
{
	
	if(fabs(ball_set.set - BALL_Encoder.ecd_angle) <= 100.0f)
	{
		ball_times++;
		if(ball_times >= 500)
		{
			ball_times = 0;
			move_flag = 1;
		}
		else 
			move_flag = 0;
	}
	if(!BALL_DUIGUAN)
	{
		has_ball_times++;
	}
	else 
		has_ball_times = 0;	
	if(move_flag)
	{
			if(!BALL_DUIGUAN && has_ball_times >= 500)
			{
					switch(ball_color)
					{ 
						case black: ball_set.set = ball_zero_angle; break;
						case white: ball_set.set = ball_zero_angle + DIS_ZERO2FEED; Insert_Q(ball_color); break;//ѹջ
						case 	pink: ball_set.set = ball_zero_angle + DIS_ZERO2FEED; Insert_Q(ball_color); break;//ѹջ
						default : break;
					}
					
			}
			else 
			{
				ball_set.set = ball_zero_angle + DIS_ZERO2DISCERN;
			}
			move_flag = 0;
	}
}

//	if(rc.sr == 1)
//	{

//	}else if(rc.sr == 3)
//	{
//		ball_set.set = ball_zero_angle;
//	}else if(rc.sr == 2)
//	{
//		
//	}
//	time_1ms_ball_demo++;
//	if(time_1ms_ball_demo<=3000)
//	{
//		ball_set.set = ball_zero_angle +DIS_ZERO2DISCERN ;
//	}
//	else if(time_1ms_ball_demo>3000&&time_1ms_ball_demo<=6000)
//	{
//		ball_set.set = ball_zero_angle;
//		
//	}else if(time_1ms_ball_demo>6000&&time_1ms_ball_demo<9000)
//	{
//		ball_set.set = ball_zero_angle + DIS_ZERO2FEED;
//	}else if(time_1ms_ball_demo>=9000)
//	{
//		time_1ms_ball_demo = 0;
//	}
//		if(!BALL_DUIGUAN)
//		{
//			move_flag = 1;
//			real_ball_color = ball_color;
//		}else
//		{
//			ball_set.set = ball_zero_angle +DIS_ZERO2DISCERN;
//		}
//		if(move_flag)
//		{
//			if(real_ball_color==white||real_ball_color==pink)
//			{
//				ball_set.set = ball_zero_angle + DIS_ZERO2FEED;
//				if((BALL_Encoder.ecd_angle<(ball_set.set-10))&&(BALL_Encoder.ecd_angle>(ball_set.set+10)))
//				{
//					ball_wait_time++;
//					if(ball_wait_time>1000)
//					{
//						ball_wait_time = 0;
//						move_flag = 0;
//					}
//				}
//					
//			}else if(real_ball_color == black)
//			{
//				ball_set.set = ball_zero_angle; 
//				if((BALL_Encoder.ecd_angle<(ball_set.set-10))&&(BALL_Encoder.ecd_angle>(ball_set.set+10)))
//				{
//					ball_wait_time++;
//					if(ball_wait_time>1000)
//					{
//						ball_wait_time = 0;
//						move_flag = 0;
//					}
//				}
//					
//			}
//		}

//}

float angle_set= 0.0f;
float angle_real = 0.0f;
float speed_set = 0.0f;
float speed_real = 0.0f;
void ball_out_update(void)
{

	//�ȴ������ᴥ����
	if(!ball_init_flag)
	{
		out[BALL_SPEED] = Calculate_Current_Value(&pid[BALL_SPEED],ball_set.speed_set, BALL_Encoder.filter_rate);
	}else
	{
	ball_set_update();
	out[BALL] = Calculate_Current_Value(&pid[BALL], ball_set.set, BALL_Encoder.ecd_angle);
	out[BALL_SPEED] = Calculate_Current_Value(&pid[BALL_SPEED], out[BALL], BALL_Encoder.filter_rate);
		
//	angle_set = ball_set.set;
//	angle_real = BALL_Encoder.ecd_angle;
//	speed_set = out[BALL];
//	speed_real = BALL_Encoder.filter_rate;
	}
	
	//��̨ ���� �����������ͺ���
	//Set_Cloud_Ball_Feed__Current((int16_t)0,(int16_t)out[BALL_SPEED],0,(int16_t)0);

}

void Insert_Q(u8 new_ball_color)
{
	if(ball_buffer[0] == no_ball)
	{
		ball_buffer[0] = new_ball_color;
	}
	else if(ball_buffer[1] == no_ball)	
	{
		ball_buffer[1] = new_ball_color;
	}
	else if(ball_buffer[2] == no_ball)	
	{
		ball_buffer[2] = new_ball_color;
	}
	
}

u8 Outsert_Q(u8 if_out)
{
	u8 color = ball_buffer[0];
	if(if_out)
	{
		for(int i = 0; i < 2; i++)
			ball_buffer[i] = ball_buffer[i + 1];
		ball_buffer[2] = no_ball;
		return color;
	}
		return color;
	
}

void Set_Cloud_Ball_Feed__Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq)//��̨ ���� ���� ���ͺ���
{
    CanTxMsg tx_message;
    tx_message.StdId = 0x1FF;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
	
	
    tx_message.Data[0] = (uint8_t)(cm1_iq >> 8);
    tx_message.Data[1] = (uint8_t)cm1_iq;
    tx_message.Data[2] = (uint8_t)(cm2_iq >> 8);
    tx_message.Data[3] = (uint8_t)cm2_iq;
    tx_message.Data[4] = (uint8_t)(cm3_iq >> 8);
    tx_message.Data[5] = (uint8_t)cm3_iq;
    tx_message.Data[6] = 0x00;
    tx_message.Data[7] = 0x00;
    CAN_Transmit(CAN1,&tx_message);
}
