#include "main.h"

int bsp_init = 0;

void BSP_Init()						//�ײ��ʼ��
{
//	while(NRF24L01_Check());
//	NRF24L01_RX_Mode();
	chassis_init();
	Ball_init();
	Feed_init();
	Cloud_init();
	ALL_Pid_Incr_Configuration();
	All_Pid_Configuration(pid);//pid������ʼ��
	bsp_init = 1;
}
