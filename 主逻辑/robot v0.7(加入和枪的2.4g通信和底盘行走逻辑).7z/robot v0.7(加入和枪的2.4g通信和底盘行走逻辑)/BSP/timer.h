#ifndef __TIMER_H__
#define __TIMER_H__

#include "main.h"

void TIM6_Configure(void);
void TIM6_Start(void);
void TIM6_Stop(void);

extern u32 time_1ms;
#endif
