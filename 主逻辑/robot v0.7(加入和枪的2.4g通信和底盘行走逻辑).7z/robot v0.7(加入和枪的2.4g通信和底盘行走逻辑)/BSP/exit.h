#ifndef _EXIT
#define _EXIT

#include "sys.h"
void EXTIX_Init(void);

#define DAODAN GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_6)
#define FENQIU GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_6)



#endif

