#ifndef __FEED
#define __FEED

#include "sys.h"

void feed_set_update(void);
void feed_out_update(void);

typedef struct Feed_set
{
	
	float set;
	float real;

}Feed_set;

enum{
	robot_await = 0,	
	robot_ammunition_feed
};

extern Feed_set feed_set;
extern int feed_init_flag;
extern float feed_zero_angle;

void Feed_init(void);





#endif

