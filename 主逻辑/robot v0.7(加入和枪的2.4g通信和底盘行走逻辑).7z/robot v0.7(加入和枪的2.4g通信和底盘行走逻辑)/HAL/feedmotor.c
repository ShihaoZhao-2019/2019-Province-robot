#include "main.h"


Feed_set feed_set = {0,0};
int robot_feed_mode = 0;
int feed_init_flag = 0; 
float feed_zero_angle = 0.0f;

void Feed_init(void)
{
	feed_set.set =  FEED_Encoder.ecd_angle;
}


void feed_set_update(void)
{
	static int arrive_zero_flag = 0;
	static int arrive_terminal_flag = 0;
	
	if(!feed_init_flag)
	{
		feed_set.set -= 0.5f;
	}else{
		
	if(robot_feed_mode == robot_await)
	{
		feed_set.set = feed_zero_angle - 8000;//���ϲ��Եó�������ֵ 9��9�� 14:16
	}else{		
		feed_set.set = feed_zero_angle;//�ȵ���λ,Ĭ������λ�෴λ��			
		if(FEED_Encoder.ecd_angle == feed_zero_angle) arrive_zero_flag = 1;//������λ��־λ
		if(arrive_zero_flag == 1) 
		{
			feed_set.set = feed_zero_angle - 8000;
			arrive_zero_flag = 0;
			robot_feed_mode = robot_await;
		}

	}
		
	}

}

void feed_out_update(void)

{
	feed_set_update();

	out[FEED] = Calculate_Current_Value(&pid[FEED], feed_set.set, FEED_Encoder.ecd_angle);
	//out[FEED_SPEED] = Calculate_Current_Value(&pid[FEED_SPEED], out[FEED], FEED_Encoder.filter_rate);
	
	Set_Cloud_Ball_Feed__Current((int16_t)out[FEED],(int16_t)0,(int16_t)0,(int16_t)0);
}


