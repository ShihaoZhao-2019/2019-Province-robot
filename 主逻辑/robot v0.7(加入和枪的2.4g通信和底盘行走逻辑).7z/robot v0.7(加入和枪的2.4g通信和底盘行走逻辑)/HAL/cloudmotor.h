#ifndef __CLOUD
#define __CLOUD

#include "sys.h"

void cloud_set_update(void);
void cloud_out_update(void);

typedef struct Cloud_set
{
	
	float set;
	float real;

}Cloud_set;

extern Cloud_set cloud_set;

void Cloud_init(void);
                               






#endif


