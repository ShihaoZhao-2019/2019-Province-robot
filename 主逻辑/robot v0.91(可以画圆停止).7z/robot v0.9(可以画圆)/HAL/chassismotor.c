#include "main.h"
#include "math.h"

Chassis_set chassis_set = {0,0,0,0};
int robot_chassis_mode = robot_walk;
int base_speed = 1500;//���̻����ٶ�
u8 stop_flag = 0;
void chassis_init(void)
{
		chassis_set.follow_set = position.pos_yaw_angle;
}


void chassis_set_update()
{

	
	//�����Ȧԭ��תȦ������
	if(chassis_set.follow_set-position.pos_yaw_angle>180)
	{
		walking_count --;
	}else if(chassis_set.follow_set-position.pos_yaw_angle<-180)
	{
		walking_count++;
	}
	
	if(walking_count>=1) robot_chassis_mode = robot_shoot;
	
	if(rc.sr == 3)
	{
		base_speed = rc.R_y * 1.51f;
		chassis_set.follow_set -= rc.L_x/2500.0f;
	}
	else if(rc.sr == 2)
	{	
		time_1ms_walk ++;//ȷ��ͣ�º��ܹ��ٴ�����;
		
		//�Ȱ��ճ����м仭Բ
		if(robot_chassis_mode == robot_walk)
		{
			base_speed = -700;
			//base_speed = rc.R_y * 1.51f;
			circle_task(1400.0f);
			
		}else if(robot_chassis_mode == robot_shoot)
		{
							
			//base_speed = rc.R_y * 1.51f;
			base_speed = -500;
			circle_task(1100.0f);
			
			if(((int)origin_circle_angle_set % 45 < 1.5f)&&(time_1ms_walk>1500)&&((int)origin_circle_angle_set % 90 > 3.0f)) stop_flag = 1;//�൱�����ĸ��ٽ��ͣ��������
			if(stop_flag == 1)
			{			
				time_1ms_walk_wait++;
				base_speed = 0;
				if(time_1ms_walk_wait>3000)
				{
					time_1ms_walk_wait = 0;	//���ֹͣ��ʱ
					stop_flag = 0;					//���ֹͣ��־λ
					time_1ms_walk = 0;			//�������ʱ��
				}
			}		
	}
		
	}
	

	chassis_set.follow_real = position.pos_yaw_angle;
	out[CHASSIS_FOLLOW] = Calculate_Current_Value(&pid[CHASSIS_FOLLOW], chassis_set.follow_set, chassis_set.follow_real );
	chassis_set.follow_speed_set = out[CHASSIS_FOLLOW];
	chassis_set.follow_speed_real = position.pos_yaw_speed / 10.0f;
	out[CHASSIS_FOLLOW_SPEED] = Calculate_Current_Value(&pid[CHASSIS_FOLLOW_SPEED], chassis_set.follow_speed_set, chassis_set.follow_speed_real );

	
}

void chassis_out_update()
{
	if(position.posx != 6.0f && position.posy != 6.0f && position.pos_yaw_angle != 6.0f && position.last_pos_yaw_speed != 6.0f)
	{
		chassis_set_update();
		
		chassis_set.cm1_real = CM1Encoder.filter_rate;
		chassis_set.cm2_real = CM2Encoder.filter_rate;
		
		out[FR] = pid_incr_calc(&pid_incr[FR], chassis_set.cm1_real, base_speed + out[CHASSIS_FOLLOW_SPEED]);
		out[FL] = pid_incr_calc(&pid_incr[FL], chassis_set.cm2_real, -base_speed + out[CHASSIS_FOLLOW_SPEED]);
//		out[FR] = pid_incr_calc(&pid_incr[FR], chassis_set.cm1_real, base_speed );
//		out[FL] = pid_incr_calc(&pid_incr[FL], chassis_set.cm2_real, -base_speed );
		Set_ChassisMotor_Current((int16_t)out[FR],(int16_t)out[FL], (int16_t)0, (int16_t)0);	
	}
}



void Set_ChassisMotor_Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq)		//���̵���������ͺ���
{
    CanTxMsg tx_message;
    tx_message.StdId = 0x200;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
    
    tx_message.Data[0] = (uint8_t)(cm1_iq >> 8);
    tx_message.Data[1] = (uint8_t)cm1_iq;
    tx_message.Data[2] = (uint8_t)(cm2_iq >> 8);
    tx_message.Data[3] = (uint8_t)cm2_iq;
    tx_message.Data[4] = (uint8_t)(cm3_iq >> 8);
    tx_message.Data[5] = (uint8_t)cm3_iq;
    tx_message.Data[6] = (uint8_t)(cm4_iq >> 8);
    tx_message.Data[7] = (uint8_t)cm4_iq;
    CAN_Transmit(CAN1,&tx_message);
}
