#include "main.h"
float cala_aimed_angle;
void cala_second_basket(void)
{
	float tana ;
	float a;
	tana = (atan((4800 - position.posy) / (2400 + position.posx))) * (180 / PI);
	
	if(chassis_set.follow_real -  scan_cnts * 360 >= 45.0f)
	{
		a = 90.0f -  (90.0f - (chassis_set.follow_real -  scan_cnts * 360) + tana);
		cala_aimed_angle = CLOUD_MIDDLE - (a + 90.0f) * 3.3333333f;
	}
	else 
	{
		a = (tana - ((chassis_set.follow_real -  scan_cnts * 360))) + 90.0f;
		cala_aimed_angle = CLOUD_MIDDLE - (180.0f - a) * 3.333333333f;
	}
	if(cala_aimed_angle - CLOUD_MIDDLE <= 1000.0f)
		cloud_set.set = cala_aimed_angle;
}
