#ifndef __BALL
#define __BALL

#include "sys.h"
//#define DIS_ZERO2DISCERN 10943
//#define DIS_ZERO2FEED  22568
#define DIS_ZERO2DISCERN 11300
#define DIS_ZERO2FEED  23000
#define OUT_Q 1
#define CHECK_CLOLR 0
#define MODE_SWITCH GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_0);//�� 1 �� 0
#define START_SWITCH GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_1);
#define BALL_DUIGUAN GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)

extern u8 ball_color;

void ball_set_update(void);
void ball_out_update(void);

typedef struct Ball_set
{
	float set;
	float real;
	
	float speed_set;
	float speed_real;
	int if_ready;
}Ball_set;

extern Ball_set ball_set;
extern int ball_init_flag;
extern float ball_zero_angle;

enum colour
{
	black,
	white,
	pink,
	no_ball
};

void Ball_init(void);
void Insert_Q(u8 ball_color);
u8 Outsert_Q(u8 if_out);
void Set_Cloud_Ball_Feed__Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq);//0x205         //0x206         //0x207


enum{
	blue,
	red
};
void start_and_mode_switch_init(void);	
void ppp(void);
//#define MODE_SWITCH GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_0);//�� 1 �� 0
//#define START_SWITCH GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_1);

extern u8 mode; extern u8 start;


#endif


