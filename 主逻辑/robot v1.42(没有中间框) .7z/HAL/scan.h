#ifndef SCAN_H_
#define SCAN_H_
#include "stm32f4xx.h"
typedef struct
{
	float yaw_angle;
	float posx;
	float posy;
	u8 info_flag;
}Scaning_Shooting_Info;

u8 check_crash_when_scaning_and_shooting(void);
extern Scaning_Shooting_Info ssinfo;
#endif

