#include "main.h"

Scaning_Shooting_Info ssinfo;

float last_posx, last_posy;
int ms1 = 0, ms2 = 0;
u8 check_crash_when_scaning_and_shooting(void)
{
int ms1 = 0, ms2 = 0;
	if(dis_buffer.scan_flag == 1)
	{
		if(fabs(chassis_set.follow_set - chassis_set.follow_real) > 5.0f)
		{
			ms1 ++ ;
			if(ms1 >= 4000)
				return 1;
		}
		else 
			ms1 = 0 ;
	}
	
	else if(dis_buffer.scan_flag == 2 || dis_buffer.scan_flag == 3)
	{
			ms1 = 0;
		 if(!ssinfo.info_flag)
		 {
			 ssinfo.yaw_angle = position.pos_yaw_angle;
			 ssinfo.posx      = position.posx;
			 ssinfo.posy      = position.posy;
			 ssinfo.info_flag = 1;
		 }
		else
		{
			if(fabs(ssinfo.yaw_angle - position.pos_yaw_angle) >= 5.0f)
				return 1;
			if(fabs(ssinfo.posx - position.posx) >= 5.0f)
				return 1;
			if(fabs(ssinfo.posy - position.posy) >= 5.0f)
				return 1;
			return 0;
		}
		return 0;		
	}
	return 0;

}



