#include "main.h"

uint64_t fireFlag = 0;
int16_t last_shift = 0;
int16_t now_shift = 0;
Function_Coefficient func_coef;
void fireMotor_stop()
{
	TIM1->CCR4 = 1000;
}

void fireMotor_fire(u16 target_distance)
{
	u16 fire;
	fire = (u16) (func_coef.xxxxxx  * target_distance * target_distance * target_distance * target_distance * target_distance * target_distance
							 +func_coef.xxxxx   * target_distance * target_distance * target_distance * target_distance * target_distance
							 +func_coef.xxxx    * target_distance * target_distance * target_distance * target_distance
						 	 +func_coef.xxx     * target_distance * target_distance * target_distance 
				       +func_coef.xx      * target_distance * target_distance
				       +func_coef.x       * target_distance
				       +func_coef.constant);
	fire = fire > 1970 ? 1970 : fire;
	fire = fire < 1100 ? 1100 : fire;
	TIM1->CCR4 = fire;
	
}

void fireMotor(u16 target_distance)
{
	fireMotor_fire(target_distance);
}

void set_func_coef(u8 basket)
{
	switch(basket)
	{
		case 100:func_coef.xxxxxx   = 0.0000000019671950590472921518203555381029;
						 func_coef.xxxxx    = -0.000001784424921863790538292511914098;
						 func_coef.xxxx     = 0.00065114299190350860991466364069424;		
						 func_coef.xxx      = -0.12219380025944663603620909952951;
					   func_coef.xx       = 12.457812874096831023962295148522;
						 func_coef.x        = -653.3490473676662304569617845118;
						 func_coef.constant = 15064.142984680695008137263357639;
						 break;
		case 90 :func_coef.xxxxxx   = 0.00000000084310483820889337718816957610015;
						 func_coef.xxxxx    = -0.00000078063587403846535020003876564898;
						 func_coef.xxxx     = 0.0002889548649978103162135056880544;
						 func_coef.xxx      = -0.054621173375176107489537002948055;
						 func_coef.xx       = 5.5755825141544299583529209485278;
						 func_coef.x        = -289.81300432388690069274161942303;
						 func_coef.constant = 7242.9267941715006600134074687958;
						 break;
		case 80 :func_coef.xxxxxx   = 0.00000000089104007491270678133004105601401;
						 func_coef.xxxxx    = -0.00000081257650861223422272366619448225;
						 func_coef.xxxx     = 0.0002953332245746184497002528868137;
						 func_coef.xxx      = -0.054637302537929116619253022690827;
						 func_coef.xx       = 5.4436948706256709229478474298958;
						 func_coef.x        = -275.75045583543266047854558564723;
						 func_coef.constant = 6782.8588490446954892831854522228;
						 break;
		case 70 :func_coef.xxxxxx   = 0.00000000072843254055285523997140762758194;
						 func_coef.xxxxx    = -0.0000006838964666712546794447914223769;
						 func_coef.xxxx     = 0.00025566259894112497398285799299344;
						 func_coef.xxx      = -0.048549010595033539883225159883295;
						 func_coef.xx       = 4.9477790202686735554493679956067;
						 func_coef.x        = -255.0475001920597719617944676429;
						 func_coef.constant = 6410.8787766901868963032029569149;
						 break;
		case 40 :func_coef.xxxxxx   = -0.00000000036048415556935640934289096473555;
						 func_coef.xxxxx    = 0.00000030657361183515256362563353338679;
						 func_coef.xxxx     = -0.00010538134357504556990609012601112;
						 func_coef.xxx      = 0.01881695680652310451175246441835;
						 func_coef.xx       = -1.831525661879139343923839078343;
						 func_coef.x        = 93.413252273951684401254169642925;
						 func_coef.constant = -754.54423964144802994269412010908;
						 break;
		default :break;
	}
}
