#include "main.h"

float origin_circle_angle_set = 0.0f;

void control_task() 
{
	if(position.posx != 6.0f && position.posy != 6.0f && position.pos_yaw_angle != 6.0f && position.last_pos_yaw_speed != 6.0f)
	{
		if(_start)
		{
			flow_led_on(6);
			if(dis_buffer.scan_flag != 2 || dis_buffer.scan_flag != 3)
				chassis_out_update();
		}
		else 
		{
			flow_led_off(6);
		}
			
	}
	cloud_out_update();
	ball_out_update();
	feed_out_update();
	
}

/******************************************************
**@brief: ָ���뾶��Բ
**				����Բ�Ƕ���������Ƕ�
**@param: radius:�趨�뾶
**
*******************************************************/

void circle_task(float radius)
{
	float x = position.posx;
	float y = position.posy;
	
	float set_r = radius;
	float real_r;
	if(!scan_cnts)
		real_r = sqrt((y-2200)*(y-2200) + (x-0)*(x-0));
	else 
		real_r = sqrt((y-2400)*(y-2400) + (x-0)*(x-0));
	float sinA = set_r/real_r;
	int flag = 0;
	if(sinA>1)
	{
		sinA = 1.0f/sinA ;
		flag = 1 ;
	}else flag = 0;
	float correct_angle = asin(sinA)* 180.0/3.1416;
	
	float tan_alpha = 0.0f;
	float alpha = 0.0f;
	
	float set_angle = 0.0f;
	
	tan_alpha = (y-2400)/(x-0);	
	alpha = atan(tan_alpha)*(180/PI);
	
	if(x>0&&y<2400){//��һ����
		set_angle = 270 + fabs(alpha);//270~360
		
	}else if(x>0&&y>2400){//�ڶ�����
		set_angle = 270 - fabs(alpha);//180~270
		
	}else if(x<0&&y>2400){//��������
		set_angle = 90 + fabs(alpha);//90~180
		
	}else if(x<0&&y<2400){//��������
		set_angle = 90 - fabs(alpha);//0~90
	
	}
	
	set_angle -= 90;
	
	origin_circle_angle_set = set_angle + walking_count * 360;
	
	if(!flag)
		chassis_set.follow_set = set_angle + (90-correct_angle) + walking_count * 360;
	else
		chassis_set.follow_set = set_angle - (90-correct_angle) + walking_count * 360;
		
	
}
