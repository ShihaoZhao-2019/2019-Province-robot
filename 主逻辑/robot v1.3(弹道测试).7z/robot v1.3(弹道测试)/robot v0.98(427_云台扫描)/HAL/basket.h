#ifndef BASKET_H_
#define BASKET_H_

#include "stm32f4xx.h"


#define aa1 GPIO_ReadInputDataBit(GPIOI,GPIO_Pin_0)
#define aa2 GPIO_ReadInputDataBit(GPIOH,GPIO_Pin_11)
#define aa3 GPIO_ReadInputDataBit(GPIOH,GPIO_Pin_10)
#define aa4 GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_15)
#define aa5 GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_14)
#define aa6 GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_13)

void cala_second_basket(void);
void keyboardInit(void);
extern float cala_aimed_angle;


extern u8 aaa1, aaa2, aaa3,  aaa4, aaa5, aaa6;
#endif
