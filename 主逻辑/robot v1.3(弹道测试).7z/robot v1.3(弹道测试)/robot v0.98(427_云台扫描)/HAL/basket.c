#include "main.h"
float cala_aimed_angle;
void cala_second_basket(void)
{
	float tana ;
	float a;
	tana = (atan((4800 - position.posy) / (2400 + position.posx))) * (180 / PI);
	
	if(chassis_set.follow_real -  scan_cnts * 360 >= 45.0f)
	{
		a = 90.0f -  (90.0f - (chassis_set.follow_real -  scan_cnts * 360) + tana);
		cala_aimed_angle = CLOUD_MIDDLE - (a + 90.0f) * 3.3333333f;
	}
	else 
	{
		a = (tana - ((chassis_set.follow_real -  scan_cnts * 360))) + 90.0f;
		cala_aimed_angle = CLOUD_MIDDLE - (180.0f - a) * 3.333333333f;
	}
	if(cala_aimed_angle - CLOUD_MIDDLE <= 1000.0f)
		cloud_set.set = cala_aimed_angle;
}

//#define aa1 GPIO_ReadInputDataBit(GPIOI,GPIO_Pin_0)
//#define aa2 GPIO_ReadInputDataBit(GPIOH,GPIO_Pin_11)			fl
//#define aa3 GPIO_ReadInputDataBit(GPIOH,GPIO_Pin_10)			CAMP
//#define aa4 GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_15)
//#define aa5 GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_14)
//#define aa6 GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_13)      start
u8 aaa1, aaa2, aaa3,  aaa4, aaa5, aaa6;
void keyboardInit(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOI | RCC_AHB1Periph_GPIOH | RCC_AHB1Periph_GPIOD, ENABLE);//ʹ��GPIOA,GPIOEʱ�� 
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOI, &GPIO_InitStructure);
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOH, &GPIO_InitStructure);
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15 | GPIO_Pin_14 | GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	delay_ms(1000);
//	aaa1 = aa1;
//	aaa2 = aa2;
//	aaa3 = aa3;
//	aaa4 = aa4;
//	aaa5 = aa5;
//	aaa6 = aa6;
}

