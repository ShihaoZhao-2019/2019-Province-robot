#include "main.h"

uint64_t fireFlag = 0;
int16_t last_shift = 0;
int16_t now_shift = 0;

void fireMotor_stop()
{
	TIM1->CCR1 = 1000;
	TIM1->CCR4 = 1000;
}

	int fire = 1600;
	u8 flag_up = 0;
	u8 flag_down = 0;
void fireMotor_fire(u16 target_distance)
{
	if(rc.sr == 3)
	{
		flag_up = 1;
		flag_down = 1;
	}
	
	if(flag_up==1&&rc.sr==1)
	{
		flag_up = 0;
		flag_down = 0;
		fire+=10;
	}
	if(flag_down==1&&rc.sr==2)
	{
		flag_up = 0;
		flag_down = 0;
		fire-=10;
	}

//	fire = (u16) (0.0001547545827041870965604108967284 * target_distance * target_distance * target_distance 
//				       -0.034729367753550149933161605986243  * target_distance * target_distance
//				       +3.679758685184292055225796502782     * target_distance
//				       +1152.0858174538541334186447784305);
//	fire = fire > 2000 ? 2000 : fire;
//	fire = fire < 1000 ? 1000 : fire;
	TIM1->CCR1 = fire;
	TIM1->CCR4 = fire;
	
}

void fireMotor(u16 target_distance)
{
	fireMotor_fire(target_distance);
}
