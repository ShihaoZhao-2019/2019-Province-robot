#include "main.h"


Feed_set feed_set = {0,0};

int robot_feed_mode = robot_await;
int feed_init_flag = 0; 
float feed_zero_angle = 0.0f;



//void Feed_init(void)
//{
//	if(!DAODAN)
//	{
//		feed_set.speed_set = 300.0f;
//		feed_init_flag = 0;
//		feed_mode_ready = 1;
//	}
//	else 
//	{
//		feed_set.speed_set = 300.0f;
//		feed_zero_angle = feed_set.set = FEED_Encoder.ecd_angle;
//		feed_init_flag = 0;
//	}	
//}


//u8 feed_mode_finish = 0;
//void feed_set_update(void)
//{

//		feed_set.set = feed_zero_angle - DISTANT;
//		
//		time_1ms_feed++;
//	if(time_1ms_feed > 2000)
//		{	
//			time_1ms_feed = 0;
//			feed_init_flag = 0;
//			Outsert_Q(OUT_Q);//��ջ
//		}
//		
//}


//void feed_out_update(void)
//{	
//	

//	if(rc.sl == 2)
//	{
//		robot_feed_mode = robot_ammunition_feed;
//	}
//	else
//	{
//		robot_feed_mode = robot_await;
//	}

////	if(Outsert_Q(0)!=no_ball&&stop_flag == 1)
////	{
////		
////		time_1ms_ball_roll ++;
////		if(time_1ms_ball_roll>4000)
////		{
////			time_1ms_ball_roll = 0;
////			robot_feed_mode = robot_ammunition_feed;
////			//robot_feed_mode = robot_await;
////		}
////	}
////else
////{
////	robot_feed_mode = robot_await;
////}

//	
//	if((robot_feed_mode == robot_ammunition_feed) && (feed_mode_ready == 1))
//	{
//		feed_init_flag = 1;
//		feed_mode_ready = 0;
//	}
//	
//	if(!feed_init_flag)//PIDѡ��
//	{
//		out[FEED_SPEED] = Calculate_Current_Value(&pid[FEED_SPEED], feed_set.speed_set, FEED_Encoder.filter_rate);
//		if(feed_mode_ready == 0)//û�е���ԭ��
//			Set_Cloud_Ball_Feed__Current((int16_t)out[FEED_SPEED],(int16_t)out[BALL_SPEED],(int16_t)out[CLOUD_SPEED],(int16_t)0);
//		else
//			Set_Cloud_Ball_Feed__Current((int16_t)0,(int16_t)out[BALL_SPEED],(int16_t)out[CLOUD_SPEED],(int16_t)0);
//	}
//	else
//	{
//		feed_set_update();
//		out[FEED] = Calculate_Current_Value(&pid[FEED], feed_set.set, FEED_Encoder.ecd_angle);
//		out[FEED_SPEED] = Calculate_Current_Value(&pid[FEED_SPEED], out[FEED], FEED_Encoder.filter_rate);
//		
//		Set_Cloud_Ball_Feed__Current((int16_t)out[FEED_SPEED],(int16_t)out[BALL_SPEED],(int16_t)0,(int16_t)0);
//	}
//}

void Feed_init(void)
{
	
	
	if(!DAODAN)//��ʼλ��
	{
		
		feed_mode_ready = 1;
		feed_init_flag = 0;
	}
	else 
	{
		feed_mode_ready = 0;
		feed_init_flag = 0;
	}	
}


//u8 feed_mode_finish = 0;
//void feed_set_update(void)
//{

//		feed_set.set = feed_zero_angle - DISTANT;
//		
//		time_1ms_feed++;
//	if(time_1ms_feed > 2000)
//		{	
//			time_1ms_feed = 0;
//			feed_init_flag = 0;
//			Outsert_Q(OUT_Q);//��ջ
//		}
//		
//}


void feed_out_update(void)
{	
	

	if(rc.sl == 2)
	{
		robot_feed_mode = robot_ammunition_feed;
	}
	else
	{
		robot_feed_mode = robot_await;
	}

//	if(Outsert_Q(0)!=no_ball&&stop_flag == 1)
//	{
//		
//		time_1ms_ball_roll ++;
//		if(time_1ms_ball_roll>4000)
//		{
//			time_1ms_ball_roll = 0;
//			robot_feed_mode = robot_ammunition_feed;
//			//robot_feed_mode = robot_await;
//		}
//	}
//else
//{
//	robot_feed_mode = robot_await;
//}

	
	if((robot_feed_mode == robot_ammunition_feed) && (feed_mode_ready == 1))
	{
		feed_init_flag = 1;
		feed_mode_ready = 0;
	}
	
	if(!feed_init_flag)//����ѡ��//����
	{
		feed_set.speed_set = 500.0f;
		feed_mode_finish_ready = 0;
	}
	else
	{
		feed_mode_ready = 0;
		feed_set.speed_set = -500.0f;
		
		if(feed_mode_finish_ready)
			time_1ms_feed++;
		if(time_1ms_feed > 500)
		{	
			time_1ms_feed = 0;
			feed_init_flag = 0;
			feed_mode_finish_ready = 0;
			Outsert_Q(OUT_Q);//��ջ
		}
		
	}
	
	if(!feed_mode_finish_ready)
	{
		out[FEED_SPEED] = Calculate_Current_Value(&pid[FEED_SPEED], feed_set.speed_set, FEED_Encoder.filter_rate);
		if((feed_mode_ready == 0) && (feed_mode_finish_ready == 0))
			Set_Cloud_Ball_Feed__Current((int16_t)out[FEED_SPEED],(int16_t)out[BALL_SPEED],(int16_t)out[CLOUD_SPEED],(int16_t)0);
		else
			Set_Cloud_Ball_Feed__Current((int16_t)0,(int16_t)out[BALL_SPEED],(int16_t)out[CLOUD_SPEED],(int16_t)0);
	}
	else
	{
		
		
		out[FEED] = Calculate_Current_Value(&pid[FEED], feed_set.set, FEED_Encoder.ecd_angle);
		out[FEED_SPEED] = Calculate_Current_Value(&pid[FEED_SPEED], out[FEED], FEED_Encoder.filter_rate);
		
		Set_Cloud_Ball_Feed__Current((int16_t)out[FEED_SPEED],(int16_t)out[BALL_SPEED],(int16_t)0,(int16_t)0);
	}

}

