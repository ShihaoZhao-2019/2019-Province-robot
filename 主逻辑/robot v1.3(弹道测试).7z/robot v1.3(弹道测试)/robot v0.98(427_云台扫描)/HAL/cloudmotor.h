#ifndef __CLOUD
#define __CLOUD

#include "sys.h"

void cloud_set_update(void);
void cloud_out_update(void);


#define CLOUD_MIDDLE -56.00f
#define READY_TO_SCAN_ANGLE (CLOUD_MIDDLE - 90.0f * 3.33333333333333333333333f)
typedef struct Cloud_set
{
	float set;
	float real;
	float speed_set;
	float speed_real;
	float back_flag;
	float target;
}Cloud_set;

typedef struct DIS_ANGLE
{
	float angle[200];
	int distance[200];

	int16_t last_distance;
	float last_angle;
	int16_t new_distance;
	float new_angle;

	float k;
	float last_k;
	float diff_angle;
	int16_t diff_dis;
	float aimed_angle;
	double aimed_dis;
	double cosa;
	u8 on_target_counts;
	u8 aimed_flag;
	u8 on_target_flag;
	u8 scan_flag;
	int16_t max_diff;
	int16_t cross_range;
	int16_t longitudinal_separation;
	int16_t max_dis;
	float max_dis_to_angle;
	int16_t on_target_dis;
	int16_t dis_x;
	int16_t dis_y;
}DIS_ANGLE;

extern DIS_ANGLE dis_buffer;
extern Cloud_set cloud_set;
extern int robot_cloud_mode;

enum{
	robot_fix,//�̶�
	robot_scan//ɨ��
	
};

void Cloud_init(void);
float Solve_angle(DIS_ANGLE *dis_buffer);
                               
extern u8 scan_finish_flag;
u8 ReadyToScan(void);
void FindTheFurthest(void);
void ClearAllScanFlags(void);
void Set_CloudCurrent(int16_t cm3_iq);

#endif


