#include "main.h"

//feed
u32 time_1ms = 0;
u32 time_1ms_feed = 0;

//walk
u32 time_1ms_walk_wait = 0;//ͣ�����ʱ��
u32 time_1ms_walk = 0;//����ʱ��
u32 time_1ms_block = 0;//���赲ʱ��
u32 time_1ms_retreat = 0;//����ʱ��

//
u32 time_1ms_ball_demo = 0;
u32 ball_wait_time = 0;//����ע��û����


//ball
u32 time_1ms_ball_roll = 0;


void TIM6_Configure(void)
{
    TIM_TimeBaseInitTypeDef  tim;
    NVIC_InitTypeDef         nvic;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,ENABLE);
    
    nvic.NVIC_IRQChannel = TIM6_DAC_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 0;
    nvic.NVIC_IRQChannelSubPriority = 3;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);
    tim.TIM_Prescaler = 90-1;        //84M internal clock
    tim.TIM_CounterMode = TIM_CounterMode_Up;
    tim.TIM_ClockDivision = TIM_CKD_DIV1;
    tim.TIM_Period = 1000;  //1ms,1000Hz
    TIM_TimeBaseInit(TIM6,&tim);
}

void TIM6_Start(void)
{
    TIM_Cmd(TIM6, ENABLE);	 
    TIM_ITConfig(TIM6, TIM_IT_Update,ENABLE);
    TIM_ClearFlag(TIM6, TIM_FLAG_Update);	
}
void TIM6_Stop(void)
{
    TIM_Cmd(TIM6, DISABLE);	 
    TIM_ITConfig(TIM6, TIM_IT_Update,DISABLE);
}

void TIM6_DAC_IRQHandler(void)  
{
    if (TIM_GetITStatus(TIM6,TIM_IT_Update)!= RESET) 
	{
		TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
		TIM_ClearFlag(TIM6, TIM_FLAG_Update);
		time_1ms++;
		//���п�������
		if((time_1ms % 500 == 0) && (time_1ms % 1000 != 0))
		{
			flow_led_on(0);
		}
		else if(time_1ms % 1000 == 0)
		{
			flow_led_off(0);		
		}
		if(bsp_init == 1)control_task();   
		
		if(time_1ms % 20 == 0)
		{
			
//				dis_buffer.last_distance = dis_buffer.new_distance;
//				dis_buffer.last_angle = dis_buffer.new_angle;
//				
//				dis_buffer.new_distance = (float)aser_ranging;
//				dis_buffer.new_angle = CLOUD_Encoder.ecd_angle;
//			
//				dis_buffer.diff_angle = dis_buffer.new_angle - dis_buffer.last_angle;
//				dis_buffer.diff_dis = dis_buffer.new_distance - dis_buffer.last_distance;
//				if(fabs((float)dis_buffer.new_distance - (float)dis_buffer.last_distance) <= 0.0001f)
//					dis_buffer.k = 0;
//				else
//					dis_buffer.k = (dis_buffer.new_distance - dis_buffer.last_distance) / (	dis_buffer.new_angle - dis_buffer.last_angle);

//				if(dis_buffer.k < -10000.0f)
//					dis_buffer.k = 0.0f;
//				else if(dis_buffer.k > 10000.0f)
//					dis_buffer.k = 0.0f;
//				
//				if(dis_buffer.k * 10000 < 0.0f)
//					dis_buffer.flag = -1;
//				else if(dis_buffer.k * 10000 > 0.0f)
//					dis_buffer.flag = 1;
//				else 
//					dis_buffer.flag = 0;
					
		}
   }
}


void TIM3_Int_Init()
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);  ///ʹ��TIM3ʱ��
	
    TIM_TimeBaseInitStructure.TIM_Period = 1000 - 1; 	//�Զ���װ��ֵ
	TIM_TimeBaseInitStructure.TIM_Prescaler= 9000 - 1;  //��ʱ����Ƶ    84000000/84/500 = 2000HZ  
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1; 
	
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStructure);//��ʼ��TIM3
	
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE); //������ʱ��3�����ж�
	TIM_Cmd(TIM3,ENABLE); //ʹ�ܶ�ʱ��3
	
	NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn; //��ʱ��3�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1; //��ռ���ȼ�1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=2; //�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}
