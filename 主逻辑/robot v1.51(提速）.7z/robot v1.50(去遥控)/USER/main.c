#include "main.h"
	u8 bsp_flag = 0;
	u8 offset_flag = 0;
	
void start_and_mode_switch_init(void);
	
	
u8 daodan = 5;
int main(void)
{
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
		delay_init(180);
		Remote_uart1_init();//ң�س�ʼ��
		BSP_Init(1);	
		led_configuration();
		flow_led_on(5);
		
	while(1)
	{
		daodan = DAODAN;
		
		if(position.posx == 6.0f && position.posy == 6.0f && position.pos_yaw_angle == 6.0f && position.last_pos_yaw_speed == 6.0f)
		{
			flow_led_on(1);
		}
		else
		{
			flow_led_off(1);
		}
//		fireMotor(200);//Ħ���ֿ���
	}
}


