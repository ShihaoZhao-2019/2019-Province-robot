#ifndef __FEED
#define __FEED

#include "sys.h"
//#define BEEN_READY 1u
//#define NOT_YET 0u
#define DISTANT 14000.0f
void feed_set_update(void);
void feed_out_update(void);

typedef struct Feed_set
{
	
	float set;
	float real;
	
	float speed_set;
	float speed_real;
	int if_ready;
}Feed_set;

enum{
	robot_await = 0,	
	robot_ammunition_feed
};

enum{
	NOT_YET = 0,	
	BEEN_READY
};

extern Feed_set feed_set;
extern int feed_init_flag;
extern float feed_zero_angle;

void Feed_init(void);
void Gantaniangde(void);

extern int robot_feed_mode;


#endif

