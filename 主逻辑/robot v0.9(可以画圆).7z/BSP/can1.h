#ifndef __CAN1_H_
#define __CAN1_H_
#include "delay.h"

void CAN1_Configure(void);				//can1��ʼ��
void CAN1_STOP(void);
void CNA1_START(void);
#endif
