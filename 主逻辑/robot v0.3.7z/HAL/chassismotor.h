#ifndef _CHASSISMOTOR_H_
#define _CHASSISMOTOR_H_

#include "delay.h"
#define keypad_K 2u
#define remote_K 1.6f
#define limit 1012u



void chassis_set_update(void);
void chassis_out_update(void);

typedef struct Chassis_set
{
	
	float cm1_set;
	float cm2_set;
	float cm3_set;
	float cm4_set;
	
	float cm1_real;
	float cm2_real;
	float cm3_real;
	float cm4_real;
	float follow_set;
	float follow_real;
	float follow_speed_set;
	float follow_speed_real;

}Chassis_set;
extern Chassis_set chassis_set;
void chassis_init(void);
void Set_ChassisMotor_Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq);


//volatile Chassis_set chassis_set;
#endif
