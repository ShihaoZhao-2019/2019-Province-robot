#ifndef __CLOUDMOTOR_H___
#define __CLOUDMOTOR_H___

#include "stm32f4xx.h"


#endif





// low -180
//middle -150
//-100
