#ifndef _BSP_H_
#define _BSP_H_

#include "delay.h"

void BSP_Init(u8 t);


#endif



