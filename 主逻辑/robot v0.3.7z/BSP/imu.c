#include "main.h"
mpu6050_real_data_t mpu6050_data;
#define GYRO_FSR 2 //陀螺仪量程设置0,±250dps;1,±500dps;2,±1000dps;3,±2000dps
#define ACCEL_FSR 0 //加速度计量程设置0,±2g;1,±4g;2,±8g;3,±16g
#define MPU_RATE 1000 //采样频率
uint8_t mpu_buf[15]={0};  
u8  MPU6050_is_DRY = 1;


volatile float angle[3] = {0};

// Fast inverse square-root
/**************************实现函数********************************************
*函数原型:	   float invSqrt(float x)
*功　　能:	   快速计算 1/Sqrt(x) 	
输入参数： 要计算的值
输出参数： 结果
*******************************************************************************/
float invSqrt(float x) {
	float halfx = 0.5f * x;
	float y = x;
	long i = *(long*)&y;
	i = 0x5f3759df - (i>>1);
	y = *(float*)&i;
	y = y * (1.5f - (halfx * y * y));
	return y;
}//快速求平方根算法

	u8 res;
u8 IMU_Configure()
{


	MPU_IIC_Init();//初始化IIC总线
	
	MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X80);	//复位MPU6050
	delay_ms(100);
	MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X00);	//唤醒MPU6050 
	MPU_Write_Byte(MPU_GYRO_CFG_REG,0x10);//陀螺仪量程设置0,±250dps;1,±500dps;2,±1000dps;3,±2000dps
	MPU_Write_Byte(MPU_ACCEL_CFG_REG,0x00);//加速度计量程设置0,±2g;1,±4g;2,±8g;3,±16g
	MPU_Write_Byte(MPU_SAMPLE_RATE_REG,1000/MPU_RATE-1);					//设置采样率
	MPU_Write_Byte(MPU_INT_EN_REG,0X00);	//关闭所有中断
	MPU_Write_Byte(MPU_USER_CTRL_REG,0X00);	//I2C主模式关闭
	MPU_Write_Byte(MPU_FIFO_EN_REG,0X00);	//关闭FIFO
	MPU_Write_Byte(MPU_INTBP_CFG_REG,0X02);	//INT引脚低电平有效
	MPU_Write_Byte(MPU_INT_EN_REG,0X01);//使能数据就绪中断
//	MPU_Write_Byte(MPU_CFG_REG,0x01);
	
	res=MPU_Read_Byte(MPU_DEVICE_ID_REG);
	if(res==MPU_ADDR)//器件ID正确
	{
		MPU_Write_Byte(MPU_PWR_MGMT1_REG,0X01);	//设置CLKSEL,PLL X轴为参考
		MPU_Write_Byte(MPU_PWR_MGMT2_REG,0X00);	//加速度与陀螺仪都工作
		MPU_Write_Byte(MPU_SAMPLE_RATE_REG,1000/MPU_RATE-1);		//设置采样率
		


		
	}else return 1;
	return 0;
}

//中断线配置
void IMU_INT_Configure()
{
	GPIO_InitTypeDef   GPIO_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;
	EXTI_InitTypeDef   EXTI_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);//使能GPIOA
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);//使能SYSCFG时钟

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//普通输入模式
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//100M
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//上拉	 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;// | GPIO_Pin_1;
	GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA2

	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource2);//PA2 连接到中断线0
	/* 配置EXTI_Line3 */
	EXTI_InitStructure.EXTI_Line = EXTI_Line2;//LINE2
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//中断事件
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //下降沿触发 
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;//使能LINE3
	EXTI_Init(&EXTI_InitStructure);//配置

	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;//外部中断3
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;//抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;//子优先级2
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//使能外部中断通道
	NVIC_Init(&NVIC_InitStructure);//配置
}

void IMU_EXIT_STOP()
{
	NVIC_InitTypeDef   NVIC_InitStructure;
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;//外部中断3
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;//抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;//子优先级2
	NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;//使能外部中断通道
	NVIC_Init(&NVIC_InitStructure);//配置
}

void IMU_EXIT_START()
{
	NVIC_InitTypeDef   NVIC_InitStructure;
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;//外部中断3
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;//抢占优先级2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;//子优先级2
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//使能外部中断通道
	NVIC_Init(&NVIC_InitStructure);//配置
}

void EXTI2_IRQHandler(void)         //中断频率1KHz
{   
    if(EXTI_GetITStatus(EXTI_Line2) != RESET)
    {    
        EXTI_ClearFlag(EXTI_Line2);          
        EXTI_ClearITPendingBit(EXTI_Line2);
        //读取原始数据
        MPU6050_is_DRY = 1;   //mpu6050中断标志
    }
}

int16_t MPU6050_Lastax,MPU6050_Lastay,MPU6050_Lastaz
				,MPU6050_Lastgx,MPU6050_Lastgy,MPU6050_Lastgz;
void Get_mpu_data(void)
{
		MPU_Read_Len(MPU_ADDR, MPU_ACCEL_XOUTH_REG,14, mpu_buf);
		MPU6050_Lastax=(((int16_t)mpu_buf[0]) << 8) | mpu_buf[1];
		MPU6050_Lastay=(((int16_t)mpu_buf[2]) << 8) | mpu_buf[3];
		MPU6050_Lastaz=(((int16_t)mpu_buf[4]) << 8) | mpu_buf[5];
		//跳过温度ADC
		MPU6050_Lastgx=(((int16_t)mpu_buf[8]) << 8) | mpu_buf[9];
		mpu6050_data.gyro[0] = MPU6050_Lastgx * GYRO_SEN;
		MPU6050_Lastgy=(((int16_t)mpu_buf[10]) << 8) | mpu_buf[11];
		mpu6050_data.gyro[1] = MPU6050_Lastgy * GYRO_SEN;
		MPU6050_Lastgz=(((int16_t)mpu_buf[12]) << 8) | mpu_buf[13];
		mpu6050_data.gyro[2] = MPU6050_Lastgz * GYRO_SEN;
	
		mpu6050_data.status = MPU_Read_Byte(MPU_MDETECT_CTRL_REG);	
}
