#include "main.h"


volatile Encoder CM1Encoder            =    {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
volatile Encoder CM2Encoder            =    {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
volatile Encoder CLOUD_Encoder         =    {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
volatile Encoder BALL_Encoder          =    {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
volatile Encoder FEED_Encoder          = 		{0,0,0,0,0,0,0,0,0,0,0,0,0,0};
volatile POSITION position             =    {0,0,0,0};

int walking_count = 0;//����Ȧ��

void Can1ReceiveMsgProcess(CanRxMsg *message)
{
	switch(message->StdId)
	{
		case CAN_ID_CM1:    	getEncoderData(&CM1Encoder, message);   	break;
            
		case CAN_ID_CM2:    	getEncoderData(&CM2Encoder, message); 	  break;
		
		case CAN_ID_MPU:			getMpuData(&position,message);						break;
		
		case CAN_ID_POS:			getMpuData(&position,message);						break;
		
		case CAN_ID_CLOUD:		getEncoderData(&CLOUD_Encoder,message);		break;
		
		case CAN_ID_BALL:			getEncoderData(&BALL_Encoder,message);		break;
		
		case CAN_ID_FEED:			getEncoderData(&FEED_Encoder,message);		break;

	}
}

void getMpuData(volatile POSITION *pos,CanRxMsg * msg)
{
	pos->pos_yaw_angle = (float)(msg->Data[0]<<24|msg->Data[1]<<16|msg->Data[2]<<8|msg->Data[3]);
	pos->pos_yaw_speed = (float)(msg->Data[4]<<24|msg->Data[5]<<16|msg->Data[6]<<8|msg->Data[7]);
	walking_count = ((int)pos->pos_yaw_angle)/360;
}

void getPosData(volatile POSITION *pos,CanRxMsg * msg)
{
	pos->posx = (float)(msg->Data[0]<<24|msg->Data[1]<<16|msg->Data[2]<<8|msg->Data[3]);
	pos->posy = (float)(msg->Data[4]<<24|msg->Data[5]<<16|msg->Data[6]<<8|msg->Data[7]);
}


void getEncoderData(volatile Encoder *v, CanRxMsg * msg)
{

	int i=0;
	int32_t temp_sum = 0;    
	v->last_raw_value = v->raw_value;
	v->raw_value = (msg->Data[0]<<8)|msg->Data[1];
	v->diff = v->raw_value - v->last_raw_value;
	if(v->diff < -4096)    //���α������ķ���ֵ���̫�󣬱�ʾȦ�������˸ı�
	{
		v->round_cnt++;
		v->ecd_raw_rate = v->diff + 8192;
	}
	else if(v->diff>4096)
	{
		v->round_cnt--;
		v->ecd_raw_rate = v->diff - 8192;
	}		
	else
	{
		v->ecd_raw_rate = v->diff;
	}
	//����õ������ı��������ֵ
	v->ecd_value = v->raw_value + v->round_cnt * 8192;
	//����õ��Ƕ�ֵ����Χ���������
	v->ecd_angle = (float)(v->raw_value - v->ecd_bias)*360/8192 + v->round_cnt * 360;
	v->rate_buf[v->buf_count++] = v->ecd_raw_rate;
	if(v->buf_count == RATE_BUF_SIZE)
	{
		v->buf_count = 0;
	}
	//�����ٶ�ƽ��ֵ
	for(i = 0;i < RATE_BUF_SIZE; i++)
	{
		temp_sum += v->rate_buf[i];
	}
	v->filter_rate = (int32_t)(temp_sum/RATE_BUF_SIZE);
	if(!v->flag)
		v->init_angle=v->ecd_angle;
	v->flag=1;
	
}
