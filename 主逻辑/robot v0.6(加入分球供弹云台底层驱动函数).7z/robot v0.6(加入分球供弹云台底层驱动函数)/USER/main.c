#include "main.h"

int main(void)
{
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
		delay_init(168);
		Remote_uart2_init();//ң�س�ʼ��
		BSP_Init();
		delay_ms(1000);
		TIM6_Configure();
		TIM6_Start();
	
	while(1)
	{	

	}
	


}

