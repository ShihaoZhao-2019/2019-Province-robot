#ifndef __FEED
#define __FEED

#include "sys.h"

void feed_set_update(void);
void feed_out_update(void);

typedef struct Feed_set
{
	
	float set;
	float real;

}Feed_set;

extern Feed_set feed_set;

void Feed_init(void);





#endif

