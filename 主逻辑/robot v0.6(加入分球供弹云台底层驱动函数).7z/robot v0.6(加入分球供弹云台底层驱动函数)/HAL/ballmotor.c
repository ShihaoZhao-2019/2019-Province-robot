#include "main.h"

Ball_set ball_set = {0,0};

void Ball_init(void)
{
	out[BALL_SPEED] = 1000;
}

void ball_set_update(void)
{
	ball_set.set = 0;

}
void ball_out_update(void)

{
	ball_set_update();

	out[BALL] = Calculate_Current_Value(&pid[BALL], ball_set.set, BALL_Encoder.ecd_angle);
	out[BALL_SPEED] = Calculate_Current_Value(&pid[BALL_SPEED], out[BALL], BALL_Encoder.filter_rate);
	
	//��̨ ���� �����������ͺ���
	Set_Cloud_Ball_Feed__Current((int16_t)out[CLOUD_SPEED],(int16_t)out[BALL_SPEED],(int16_t)out[FEED_SPEED],(int16_t)0);

}


void Set_Cloud_Ball_Feed__Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq)//��̨ ���� ���� ���ͺ���
{
    CanTxMsg tx_message;
    tx_message.StdId = 0x1FF;
    tx_message.IDE = CAN_Id_Standard;
    tx_message.RTR = CAN_RTR_Data;
    tx_message.DLC = 0x08;
    
    tx_message.Data[0] = (uint8_t)(cm1_iq >> 8);
    tx_message.Data[1] = (uint8_t)cm1_iq;
    tx_message.Data[2] = (uint8_t)(cm2_iq >> 8);
    tx_message.Data[3] = (uint8_t)cm2_iq;
    tx_message.Data[4] = (uint8_t)(cm3_iq >> 8);
    tx_message.Data[5] = (uint8_t)cm3_iq;
    tx_message.Data[6] = (uint8_t)(cm4_iq >> 8);
    tx_message.Data[7] = (uint8_t)cm4_iq;
    CAN_Transmit(CAN1,&tx_message);
}
