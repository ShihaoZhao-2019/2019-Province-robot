#include "main.h"

Feed_set feed_set = {0,0};

void Feed_init(void)
{
	out[FEED_SPEED] = 1000;
}


void feed_set_update(void)
{
	feed_set.set = 0;

}

void feed_out_update(void)

{
	feed_set_update();

	out[FEED] = Calculate_Current_Value(&pid[FEED], feed_set.set, FEED_Encoder.ecd_angle);
	out[FEED_SPEED] = Calculate_Current_Value(&pid[FEED_SPEED], out[FEED], FEED_Encoder.filter_rate);
}


