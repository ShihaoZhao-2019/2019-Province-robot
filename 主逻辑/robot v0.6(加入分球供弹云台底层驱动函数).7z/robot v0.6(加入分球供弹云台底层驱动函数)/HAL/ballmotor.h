#ifndef __BALL
#define __BALL

#include "sys.h"

void ball_set_update(void);
void ball_out_update(void);

typedef struct Ball_set
{
	
	float set;
	float real;

}Ball_set;

extern Ball_set ball_set;

void Ball_init(void);
                                          //0x205         //0x206         //0x207
void Set_Cloud_Ball_Feed__Current(int16_t cm1_iq, int16_t cm2_iq, int16_t cm3_iq, int16_t cm4_iq);





#endif


