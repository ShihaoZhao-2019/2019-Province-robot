#include "main.h"

Cloud_set cloud_set = {0,0};

void Cloud_init(void)
{
	out[CLOUD_SPEED] = 1000;
}


void cloud_set_update(void)
{
	cloud_set.set = 0;

}

void cloud_out_update(void)

{
	cloud_set_update();

	out[CLOUD] = Calculate_Current_Value(&pid[CLOUD], cloud_set.set, CLOUD_Encoder.ecd_angle);
	out[CLOUD_SPEED] = Calculate_Current_Value(&pid[CLOUD_SPEED], out[CLOUD], CLOUD_Encoder.filter_rate);
}


