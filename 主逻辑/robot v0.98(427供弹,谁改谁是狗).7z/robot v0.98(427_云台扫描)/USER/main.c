#include "main.h"
	u8 bsp_flag = 0;
	u8 offset_flag = 0;
	
void start_and_mode_switch_init(void);
	
	
u8 daodan = 5;
int main(void)
{
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
		delay_init(180);
		Remote_uart1_init();//ң�س�ʼ��
		start_and_mode_switch_init();
		BSP_Init(1);	
		led_configuration();
		flow_led_on(5);

	while(1)
	{
		daodan = DAODAN;
		if(aser_ranging <= 50.0f)
		{
				flow_led_off(3);
		}
		else 
		{
			flow_led_on(3);
		}
		if(aser_ranging2 <= 50.0f)
		{
				flow_led_off(4);
		}
		else 
		{
			flow_led_on(4);
		}		

		fireMotor(200);//Ħ���ֿ���
	}
}


