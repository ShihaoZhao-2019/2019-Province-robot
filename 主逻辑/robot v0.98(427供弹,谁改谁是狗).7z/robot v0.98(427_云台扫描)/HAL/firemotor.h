#ifndef _FIREMOTOR_H_
#define _FIREMOTOR_H_
#include "sys.h"
void fireMotor_stop(void);
void fireMotor_fire(u16 target_distance);
void fireMotor(u16 target_distance);

#endif






