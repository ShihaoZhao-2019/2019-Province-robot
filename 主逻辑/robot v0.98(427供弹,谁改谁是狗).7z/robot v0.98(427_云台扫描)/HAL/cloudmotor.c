#include "main.h"

Cloud_set cloud_set = {0,0};
DIS_ANGLE dis_buffer = {0};//����buffer
 
float SET_CENTER = 0.0f;//��̨��λ��
float beat_angle = 0.0f;//�����λ��
int max_distance = 0;//��Զ����
int robot_cloud_mode = robot_scan;
uint64_t scan_over_cnts = 0;
void Cloud_init(void)
{
	cloud_set.set = CLOUD_Encoder.ecd_angle;
	cloud_set.back_flag = 0;
	cloud_set.target = CLOUD_MIDDLE;
	dis_buffer.scan_flag = 0;
}

u8 scan_finish_flag = 0;
void cloud_set_update(void)
{
	
//	if(dis_buffer.aimed_flag)
//	{
//		scan_finish_flag = 1;
//	}
	if(!cloud_set.back_flag)
	{
		if((int)cloud_set.set != (int)cloud_set.target)
		{
			cloud_set.set = cloud_set.set < cloud_set.target ? cloud_set.set +0.05f : cloud_set.set - 0.05f;
		}
		else 
			cloud_set.back_flag = 1;
			SET_CENTER = cloud_set.set;
	}
	else 
	{

	if(rc.sl <= 1)						//ȫ�Զ�ɨ��ģʽ 30�ż���
	{
		 if(dis_buffer.scan_flag == 0)
		 {
			 scan_over_cnts = 0;
		 }
		 if(dis_buffer.scan_flag == 1)							//�ռ�״̬ ��̨����ȴ�ɨ���ź�
		 {		
			 scan_over_cnts = 0;
			 if(ReadyToScan())
				 dis_buffer.scan_flag = 2;
		 }
		 else if(dis_buffer.scan_flag == 2)					// ��ʼɨ�� 
		 {
			 scan_over_cnts = 0;
			 cloud_set.set += 0.05f;
		 }
		 else if(dis_buffer.scan_flag == 3)					//ɨ����� �ҵ���Զ�� ���Կ�ʼ���
		 {
			 scan_over_cnts++;
			 if(scan_over_cnts <= 1000)
			 {
				 dis_buffer.dis_x = 2400 - (dis_buffer.cross_range - 5)* 10;
				 dis_buffer.dis_y = (dis_buffer.longitudinal_separation + 5) * 10;
				 send_pos_data(dis_buffer.dis_x, dis_buffer.dis_y, 1);
			 }
				 
			 else if(scan_over_cnts > 1000 && scan_over_cnts <= 3000)
				 send_pos_data(dis_buffer.dis_x, dis_buffer.dis_y, 0);
			 else if(rc.sr == 2)
			 {
				 ClearAllScanFlags();
				 chassis_set.robot_mode = 1;
				 dis_buffer.scan_flag = 5;
			 }
				 
		 }
		 else if(dis_buffer.scan_flag == 4)					//ɨ����� δ�ҵ���Զ�� �ȴ���һָ��
		 {
			 scan_over_cnts = 0;
		 }
	}
}
	
	
	//��ʵֵ����
	cloud_set.real = CLOUD_Encoder.ecd_angle;
	cloud_set.speed_real = CLOUD_Encoder.filter_rate;
	
}

void cloud_out_update(void)
{
	{
		cloud_set_update();
		out[CLOUD] = Calculate_Current_Value(&pid[CLOUD], cloud_set.set, cloud_set.real);
		out[CLOUD_SPEED] = Calculate_Current_Value(&pid[CLOUD_SPEED], out[CLOUD], cloud_set.speed_real);
//		if(chassis_set.robot_mode == 3)
//			out[CLOUD_SPEED] = 0;
		Set_Cloud_Ball_Feed__Current((int16_t)0,(int16_t)0,(int16_t)out[CLOUD_SPEED],(int16_t)0);		
	}

}
u16 ready_to_scan_cnts; 
u8 ReadyToScan(void)
{
//	chassis_set.follow_set = 180.0f;
//	cloud_set.set = READY_TO_SCAN_ANGLE;
	if(fabs(cloud_set.set - CLOUD_Encoder.ecd_angle) < 1.0f && fabs(chassis_set.follow_set - chassis_set.follow_real) <= 2.0f)
//		if(fabs(cloud_set.set - CLOUD_Encoder.ecd_angle) < 1.0f )
	{
		ready_to_scan_cnts++;
		if(fabs(aser_ranging2 - aser_ranging) >= 40.0f && ready_to_scan_cnts >= 800)
		{
			dis_buffer.cross_range = aser_ranging2 + 25;
			ready_to_scan_cnts = 0;
			flow_led_on(7);
			return 1;
		}
		flow_led_off(7);
		return 0;
	}
	flow_led_off(7);
	ready_to_scan_cnts = 0;
	return 0;
}
void FindTheFurthest(void)
{	
	if(dis_buffer.aimed_angle >= 90.0f)    //�����ɨ��Ƕȹ��� �ж�Ϊ�Ѿ��Ѱ�
	{
		dis_buffer.scan_flag = 4;
	}
	dis_buffer.aimed_angle = fabs(CLOUD_Encoder.ecd_angle - READY_TO_SCAN_ANGLE) / 3.33333333333333333;
	dis_buffer.cosa = cos((double)dis_buffer.aimed_angle * 0.01745329251994329576923690768489);
	dis_buffer.aimed_dis = (double)dis_buffer.cross_range /  dis_buffer.cosa;
	
	if(fabs(dis_buffer.aimed_dis - aser_ranging) <= 15.0f)
	{
		dis_buffer.on_target_counts ++;
		if(dis_buffer.on_target_counts >= 15)
		{
			dis_buffer.on_target_flag = 1;
			dis_buffer.on_target_dis = aser_ranging;
		}
	}
	else 
		dis_buffer.on_target_counts = 0;
	dis_buffer.last_distance =  dis_buffer.new_distance;
	dis_buffer.new_distance = aser_ranging;								
	dis_buffer.diff_dis = (int16_t)(dis_buffer.new_distance - dis_buffer.on_target_dis);
	if(dis_buffer.on_target_flag)
	{
		if(dis_buffer.diff_dis >= dis_buffer.max_diff)
		{
			dis_buffer.max_diff = dis_buffer.diff_dis;
			dis_buffer.max_dis_to_angle = CLOUD_Encoder.ecd_angle;
		}
		else 
		{
			dis_buffer.max_dis = dis_buffer.max_diff + dis_buffer.on_target_dis;
//			dis_buffer.longitudinal_separation = dis_buffer.cross_range * tan(dis_buffer.aimed_angle * 0.01745329251994329576923690768489f);
			dis_buffer.longitudinal_separation = sqrt(dis_buffer.max_dis * dis_buffer.max_dis - dis_buffer.cross_range * dis_buffer.cross_range);
			dis_buffer.aimed_flag = 1;
			dis_buffer.scan_flag = 3;
			cloud_set.set = dis_buffer.max_dis_to_angle;			
		}

	}

}
void ClearAllScanFlags(void)
{
	dis_buffer.aimed_angle = 0.0f;
	dis_buffer.cosa = 0.0;
	dis_buffer.aimed_dis = 0.0;
	dis_buffer.on_target_counts = 0;
	dis_buffer.on_target_flag = 0;
	dis_buffer.on_target_dis = 0;
	dis_buffer.new_distance = 0;
	dis_buffer.diff_dis = 0;
	dis_buffer.max_diff = 0;
	dis_buffer.max_dis_to_angle = 0;
	dis_buffer.max_dis = 0;
	dis_buffer.longitudinal_separation = 0;
	dis_buffer.aimed_flag = 0;
	dis_buffer.cross_range = 0;
	dis_buffer.dis_x = 0;
	dis_buffer.dis_y = 0;
}
