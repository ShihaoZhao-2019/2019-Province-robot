#ifndef BASKET_H_
#define BASKET_H_

#include "stm32f4xx.h"
void cala_second_basket(void);
extern float cala_aimed_angle;
#endif
