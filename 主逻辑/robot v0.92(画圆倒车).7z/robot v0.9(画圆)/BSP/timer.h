#ifndef __TIMER_H__
#define __TIMER_H__

#include "main.h"

void TIM6_Configure(void);
void TIM6_Start(void);
void TIM6_Stop(void);
void TIM4_FireMotor_Configure(void);

extern u32 time_1ms;
extern u32 time_1ms_feed;
extern u32 time_1ms_walk_wait ;
extern u32 time_1ms_walk;
extern u32 time_1ms_block;
extern u32 time_1ms_retreat;
#endif
