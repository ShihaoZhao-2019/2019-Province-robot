#include "main.h"
float cala_aimed_angle;
Basket_Info basket_info;
void cala_second_basket(void)
{
	float tana ;
	float a;
	tana = (atan((4800 - position.posy) / (2400 + position.posx))) * (180 / PI);
	
	if(chassis_set.follow_real -  scan_cnts * 360 >= 45.0f)
	{
		a = 90.0f -  (90.0f - (chassis_set.follow_real -  scan_cnts * 360) + tana);
		cala_aimed_angle = CLOUD_MIDDLE - (a + 90.0f) * 3.3333333f;
	}
	else 
	{
		a = (tana - ((chassis_set.follow_real -  scan_cnts * 360))) + 90.0f;
		cala_aimed_angle = CLOUD_MIDDLE - (180.0f - a) * 3.333333333f;
	}
	if(cala_aimed_angle - CLOUD_MIDDLE <= 1000.0f)
		cloud_set.set = cala_aimed_angle;
}

void keyboardInit(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOI | RCC_AHB1Periph_GPIOH | RCC_AHB1Periph_GPIOD, ENABLE);//ʹ��GPIOA,GPIOEʱ�� 
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_Init(GPIOI, &GPIO_InitStructure);
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_Init(GPIOH, &GPIO_InitStructure);
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15 | GPIO_Pin_14 | GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	delay_ms(1000);
}

u8 check_quadrant(void)
{
	if(position.posy < 2400 && position.posx > 0)
		return 1;
	else if(position.posy < 2400 && position.posx < 0)
		return 4;
	else if(position.posy > 2400 && position.posx > 0)
		return 2;
	else if(position.posy > 2400 && position.posx < 0)
		return 3;
	return 0;
}

void get_camp_info(void)
{
	if(CAMP == red)
	{
		if(BASKET_1 && BASKET_2)
		{
			basket_info.stop_angle1 = 225.0f;
			basket_info.stop_angle2 = 135.0f;
			basket_info.height1 = 80;
			basket_info.height1 = 90;
		}
		else if(BASKET_2 && BASKET_3)
		{
			basket_info.stop_angle1 = 225.0f;
			basket_info.stop_angle2 = 135.0f;
			basket_info.height1 = 80;
			basket_info.height1 = 90;
		}
		else if(BASKET_3 && BASKET_4)
		{
			basket_info.stop_angle1 = 225.0f;
			basket_info.stop_angle2 = 135.0f;
			basket_info.height1 = 80;
			basket_info.height1 = 90;
		}
		else if(BASKET_1 && BASKET_3)
		{
			basket_info.stop_angle1 = 225.0f;
			basket_info.stop_angle2 = 135.0f;
			basket_info.height1 = 80;
			basket_info.height1 = 90;
		}
		else if(BASKET_2 && BASKET_4)
		{
			basket_info.stop_angle1 = 225.0f;
			basket_info.stop_angle2 = 135.0f;
			basket_info.height1 = 80;
			basket_info.height1 = 90;
		}
	}
}
